
import dotenv from 'dotenv';
import path from 'path';

// Load .env.local explicitly
dotenv.config({ path: path.resolve(process.cwd(), '.env.local') });

async function checkAuth() {
    const { supabase } = await import('../lib/supabase');

    console.log('Checking Supabase Auth...');
    try {
        // Attempt to sign in with a known non-existent user to test the endpoint
        const { data, error } = await supabase.auth.signInWithPassword({
            email: 'non-existent-user@example.com',
            password: 'wrong-password',
        });

        if (error) {
            // We expect an error, but we want to make sure it's the RIGHT error.
            // "Invalid login credentials" means we successfully talked to Supabase Auth.
            if (error.status === 400 && (error.message.includes('Invalid login credentials') || error.message.includes('Email not confirmed'))) {
                console.log('SUCCESS: Supabase Auth is reachable! (Received expected invalid credentials error)');
            } else {
                console.log('WARNING: Received an unexpected error:', error.message);
                console.log('Status:', error.status);
            }
        } else {
            console.log('Unexpected success (should not happen for fake user):', data);
        }
    } catch (err) {
        console.error('CRITICAL: Network or Client error:', err);
    }
}

checkAuth();
