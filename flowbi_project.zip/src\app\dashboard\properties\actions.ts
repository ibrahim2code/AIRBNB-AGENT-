
'use server'

import { createClient } from '@/utils/supabase/server'
import { revalidatePath } from 'next/cache'

export async function toggleAIAutomation(propertyId: string, currentState: boolean) {
    const supabase = await createClient()

    const { error } = await supabase
        .from('properties')
        .update({ ai_automation_enabled: !currentState })
        .eq('id', propertyId)

    if (error) {
        console.error('Error toggling AI automation:', error)
        return { error: 'Failed to update AI settings' }
    }

    revalidatePath('/dashboard')
    revalidatePath('/dashboard/inbox')
    return { success: true }
}
