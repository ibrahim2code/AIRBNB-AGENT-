
import { type NextRequest, NextResponse } from 'next/server'
import { updateSession } from '@/utils/supabase/middleware'
import { createServerClient } from '@supabase/ssr'

export async function middleware(request: NextRequest) {
    // 1. Update session (refresh tokens) and get the response we will eventually return
    // We need to capture the response from updateSession because it handles cookie setting
    const response = await updateSession(request)

    // 2. Check for protected routes
    if (request.nextUrl.pathname.startsWith('/dashboard')) {
        // We need to check auth status again essentially, or rely on what updateSession did.
        // Since updateSession logic is encapsulated, let's just do a quick check here 
        // OR better yet, update src/utils/supabase/middleware.ts to handle redirection.
        // BUT, since we want to keep it simple, we can just do this:

        const supabase = createServerClient(
            process.env.NEXT_PUBLIC_SUPABASE_URL!,
            process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
            {
                cookies: {
                    getAll() {
                        return request.cookies.getAll()
                    },
                    setAll(cookiesToSet) {
                        // We don't need to set cookies here, updateSession already set them on 'response'
                        // This is just for reading to check auth
                    },
                },
            }
        )
        const { data: { user } } = await supabase.auth.getUser()
        if (!user) {
            return NextResponse.redirect(new URL('/login', request.url))
        }
    }

    return response
}

export const config = {
    matcher: [
        /*
         * Match all request paths except for the ones starting with:
         * - _next/static (static files)
         * - _next/image (image optimization files)
         * - favicon.ico (favicon file)
         * Feel free to modify this pattern to include more paths.
         */
        '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
    ],
}
