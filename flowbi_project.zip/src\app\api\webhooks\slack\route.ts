
import { createClient } from '@/utils/supabase/server'
import { sendAirbnbMessage } from '@/lib/airbnb'

export async function POST(request: Request) {
    const supabase = await createClient()
    const formData = await request.formData()
    const payloadRaw = formData.get('payload') as string

    if (!payloadRaw) return new Response('Missing payload', { status: 400 })

    const payload = JSON.parse(payloadRaw)
    const action = payload.actions[0]
    const messageId = action.value
    const actionId = action.action_id

    // 1. Fetch the pending message
    const { data: message, error: fetchError } = await supabase
        .from('messages')
        .select('*, properties(*)')
        .eq('id', messageId)
        .single()

    if (fetchError || !message) {
        return new Response('Message not found', { status: 404 })
    }

    if (actionId === 'approve_reply') {
        const editedReply = payload.state.values.reply_block.reply_input.value

        // 2. Send to Guest via Platform API
        if (message.source === 'airbnb') {
            await sendAirbnbMessage(message.external_thread_id, editedReply)
        } else if (message.source === 'whatsapp') {
            console.log(`[MOCK] Sending WhatsApp message to ${message.external_guest_id}: ${editedReply}`)
            // await sendWhatsAppMessage(...)
        }

        // 3. Update DB
        await supabase.from('messages').update({
            content: editedReply,
            status: 'COMPLETED'
        }).eq('id', messageId)

        // 4. Respond to Slack to update UI
        return Response.json({
            replace_original: true,
            text: `✅ *Sent to Guest:* ${editedReply}`
        })
    }

    if (actionId === 'reject_reply') {
        await supabase.from('messages').update({
            status: 'REJECTED'
        }).eq('id', messageId)

        return Response.json({
            replace_original: true,
            text: `❌ *Reply Rejected*`
        })
    }

    return new Response('OK', { status: 200 })
}
