
'use server'

import { createClient } from '@/utils/supabase/server'
import { revalidatePath } from 'next/cache'

/**
 * Mocks the Airbnb OAuth connection process.
 * In production, this would involve exchanging an auth code for a token.
 */
export async function connectAirbnbAccount() {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) return { error: 'Not authenticated' }

    // Update user profile/settings to indicate they are connected
    // For now, we'll store this in a metadata column or a settings table
    const { error } = await supabase
        .from('profiles')
        .update({
            airbnb_connected: true,
            airbnb_connected_at: new Date().toISOString()
        })
        .eq('id', user.id)

    if (error) {
        console.error('Connection error:', error)
        return { error: 'Failed to connect account' }
    }

    revalidatePath('/dashboard/settings')
    return { success: true }
}

export async function disconnectAirbnbAccount() {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) return { error: 'Not authenticated' }

    const { error } = await supabase
        .from('profiles')
        .update({
            airbnb_connected: false,
            airbnb_connected_at: null
        })
        .eq('id', user.id)

    if (error) return { error: 'Failed to disconnect' }

    revalidatePath('/dashboard/settings')
    return { success: true }
}
