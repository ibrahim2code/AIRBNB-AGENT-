
'use server'

import { createClient } from '@/utils/supabase/server'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'

export async function addProperty(formData: FormData) {
    const supabase = await createClient()

    // Get current user
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
        throw new Error('User not authenticated')
    }

    const name = formData.get('name') as string
    const address = formData.get('address') as string
    const description = formData.get('description') as string
    const price = formData.get('price') as string

    const { error } = await supabase.from('properties').insert({
        owner_id: user.id,
        name,
        address,
        description,
        price_per_night: parseFloat(price),
    })

    if (error) {
        console.error('Error adding property:', error)
        return { error: 'Failed to add property' }
    }

    revalidatePath('/dashboard')
    return { success: true }
}
