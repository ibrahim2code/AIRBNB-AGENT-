# Flowbi | The Intelligence Layer for Short-Term Rentals

Flowbi is an elite AI operating system designed for modern property managers. Powered by DeepSeek-V3, Flowbi acts as a high-end AI concierge that automates guest communications, dynamic pricing, and logistics with technical precision.

Official Domain: **[flowbi.online](https://flowbi.online)**

## Getting Started

First, run the development server:

```bash
npm run dev
```

Open [https://flowbi.online](https://flowbi.online) (or local dev environment) to see the intelligence layer in action.

## Configuration

To enable the Flowbi Intelligence Layer, configure your environment variables in `.env.local`:

```bash
# OpenRouter (DeepSeek-V3) - Primary Concierge
OPENROUTER_API_KEY=your_openrouter_key

# Google Gemini - Technical Fallback
GEMINI_API_KEY=your_gemini_key

# Supabase - Data Core
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
```

## AI Architecture

Flowbi utilizes an orchestrated AI stack for billionaire-level service quality:
1.  **DeepSeek-V3 (via OpenRouter)**: The primary elite concierge.
2.  **Google Gemini**: Technical fallback for resilient guest support.
