
'use server'

import { createClient } from '@/utils/supabase/server'
import { revalidatePath } from 'next/cache'

export async function createAutomation(formData: FormData) {
    const supabase = await createClient()

    const propertyId = formData.get('property_id') as string
    const triggerType = formData.get('trigger_type') as string
    const actionType = formData.get('action_type') as string
    const templateContent = formData.get('template_content') as string

    const { error } = await supabase.from('automations').insert({
        property_id: propertyId,
        trigger_type: triggerType,
        action_type: actionType, // Fixed: was using triggerType by mistake in thought process
        template_content: templateContent,
        is_active: true
    })

    if (error) {
        console.error('Error creating automation:', error)
        return { error: 'Failed to create automation' }
    }

    revalidatePath('/dashboard/automations')
    return { success: true }
}

export async function toggleAutomation(id: string, currentState: boolean) {
    const supabase = await createClient()

    const { error } = await supabase.from('automations')
        .update({ is_active: !currentState })
        .eq('id', id)

    if (error) {
        return { error: 'Failed to update automation' }
    }

    revalidatePath('/dashboard/automations')
    return { success: true }
}

export async function deleteAutomation(id: string) {
    const supabase = await createClient()

    const { error } = await supabase.from('automations')
        .delete()
        .eq('id', id)

    if (error) {
        return { error: 'Failed to delete automation' }
    }

    revalidatePath('/dashboard/automations')
    return { success: true }
}
