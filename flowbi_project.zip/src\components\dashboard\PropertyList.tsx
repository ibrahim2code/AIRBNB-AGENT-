
import { createClient } from '@/utils/supabase/server'
import { Card } from '@/components/ui/Card'
import { Home, MapPin, DollarSign, MessageSquare, RefreshCcw, Calendar } from 'lucide-react'
import { AIAutomationToggle } from './AIAutomationToggle'
import Link from 'next/link'

export async function PropertyList() {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()

    const { data: properties } = await supabase
        .from('properties')
        .select('*')
        .eq('owner_id', user?.id)
        .order('created_at', { ascending: false })

    if (!properties || properties.length === 0) {
        return (
            <div className="text-center py-12 bg-gray-50 rounded-lg border border-dashed border-gray-300">
                <Home className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">No properties</h3>
                <p className="mt-1 text-sm text-gray-500">Get started by creating a new property.</p>
            </div>
        )
    }

    return (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {properties.map((property) => (
                <Card key={property.id} className="overflow-hidden hover:shadow-lg transition-all transform hover:-translate-y-1 group">
                    <div className="p-6">
                        <div className="flex items-center justify-between mb-4">
                            <div className="h-10 w-10 rounded-xl bg-indigo-50 flex items-center justify-center group-hover:bg-indigo-600 transition-colors relative">
                                <Home className="h-5 w-5 text-indigo-600 group-hover:text-white" />
                                {property.ical_link && (
                                    <div className="absolute -top-1 -right-1 size-3 bg-green-500 rounded-full border-2 border-white" title="Calendar Synced" />
                                )}
                            </div>
                            <div className="flex items-center gap-3">
                                {property.last_sync_at && (
                                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter flex items-center gap-1">
                                        <RefreshCcw size={10} className="animate-spin-slow" />
                                        Sync: {new Date(property.last_sync_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                    </span>
                                )}
                                <AIAutomationToggle
                                    propertyId={property.id}
                                    initialState={property.ai_automation_enabled}
                                />
                            </div>
                        </div>

                        <div className="flex justify-between items-start mb-2">
                            <h3 className="text-lg font-bold text-gray-900 truncate flex-1" title={property.name}>
                                {property.name}
                            </h3>
                            <Link
                                href="/dashboard/inbox"
                                className="ml-2 p-1.5 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                                title="View Messages"
                            >
                                <MessageSquare size={18} />
                            </Link>
                        </div>

                        <div className="mt-4 space-y-3">
                            <div className="flex items-center text-sm text-gray-500">
                                <div className="h-7 w-7 rounded-lg bg-gray-100 flex items-center justify-center mr-3">
                                    <MapPin className="h-4 w-4 text-gray-400" />
                                </div>
                                <span className="truncate">{property.address || 'No address'}</span>
                            </div>
                            <div className="flex items-center justify-between">
                                <div className="flex items-center text-sm font-semibold text-gray-900">
                                    <div className="h-7 w-7 rounded-lg bg-green-50 flex items-center justify-center mr-3">
                                        <DollarSign className="h-4 w-4 text-green-600" />
                                    </div>
                                    {property.price_per_night} / night
                                </div>
                                {property.ical_link && (
                                    <div className="flex items-center gap-1 text-[10px] font-black text-green-600 uppercase tracking-widest bg-green-50 px-2 py-0.5 rounded-full">
                                        <Calendar size={10} /> Live
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    <div className="bg-gradient-to-r from-gray-50 to-white px-6 py-4 border-t border-gray-100">
                        <div className="text-xs text-gray-400 line-clamp-2 italic leading-relaxed">
                            {property.description || '"A beautiful setting for your next adventure..."'}
                        </div>
                    </div>
                </Card>
            ))}
        </div>
    )
}
