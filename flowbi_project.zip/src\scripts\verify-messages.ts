
import dotenv from 'dotenv';
import path from 'path';
import { createClient } from '@supabase/supabase-js';

// Load .env.local
dotenv.config({ path: path.resolve(process.cwd(), '.env.local') });

const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

async function checkColumns() {
    console.log('Checking "messages" columns...');
    try {
        // We attempt to select just the source column.
        // If it doesn't exist, Supabase will return an error with code 'PGRST204' or '42703'
        const { error } = await supabase.from('messages').select('source').limit(1);

        if (error) {
            console.log('FAILED: Column "source" is missing or inaccessible.');
            console.log('Error Message:', error.message);
            console.log('Error Code:', error.code);
        } else {
            console.log('SUCCESS: Column "source" exists.');
        }
    } catch (err) {
        console.error('Unexpected error:', err);
    }
}

checkColumns();
