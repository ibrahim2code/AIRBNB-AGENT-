
import Link from "next/link";
import { Github, Twitter, Linkedin, Mail, MapPin, Phone } from "lucide-react";

export function Footer() {
    return (
        <footer className="border-t border-border/40 bg-background/50 backdrop-blur-md pt-20 pb-12">
            <div className="container px-6 grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
                <div className="col-span-1 md:col-span-1 space-y-6">
                    <Link href="/" className="flex items-center gap-2 group">
                        <div className="size-8 rounded bg-primary/20 flex items-center justify-center">
                            <div className="size-4 rounded-sm bg-primary rotate-45" />
                        </div>
                        <span className="text-xl font-bold tracking-tighter uppercase italic">Flow<span className="text-primary not-italic">bi</span></span>
                    </Link>
                    <p className="text-muted-foreground text-sm leading-relaxed max-w-xs">
                        The ultimate AI operating system for modern property management.
                    </p>
                    <div className="flex items-center gap-4">
                        <a href="#" className="p-2 rounded-lg bg-secondary hover:text-primary transition-colors"><Twitter size={18} /></a>
                        <a href="#" className="p-2 rounded-lg bg-secondary hover:text-primary transition-colors"><Github size={18} /></a>
                        <a href="#" className="p-2 rounded-lg bg-secondary hover:text-primary transition-colors"><Linkedin size={18} /></a>
                    </div>
                </div>

                <div className="space-y-6">
                    <h4 className="text-sm font-black uppercase tracking-widest text-foreground">Platform</h4>
                    <ul className="space-y-4 text-sm text-muted-foreground font-medium">
                        <li><Link href="#features" className="hover:text-primary transition-colors">AI Co-Host</Link></li>
                        <li><Link href="#pricing" className="hover:text-primary transition-colors">Pricing</Link></li>
                        <li><Link href="#" className="hover:text-primary transition-colors">Integrations</Link></li>
                        <li><Link href="#" className="hover:text-primary transition-colors">Enterprise</Link></li>
                    </ul>
                </div>

                <div className="space-y-6">
                    <h4 className="text-sm font-black uppercase tracking-widest text-foreground">Resources</h4>
                    <ul className="space-y-4 text-sm text-muted-foreground font-medium">
                        <li><Link href="#" className="hover:text-primary transition-colors">Documentation</Link></li>
                        <li><Link href="#" className="hover:text-primary transition-colors">API Keys</Link></li>
                        <li><Link href="#" className="hover:text-primary transition-colors">Host Tutorials</Link></li>
                        <li><Link href="#" className="hover:text-primary transition-colors">Blog</Link></li>
                    </ul>
                </div>

                <div className="space-y-6">
                    <h4 className="text-sm font-black uppercase tracking-widest text-foreground">Company</h4>
                    <ul className="space-y-4 text-sm text-muted-foreground font-medium">
                        <li><Link href="#" className="hover:text-primary transition-colors">About Us</Link></li>
                        <li><Link href="#" className="hover:text-primary transition-colors">Privacy Policy</Link></li>
                        <li><Link href="#" className="hover:text-primary transition-colors">Terms of Service</Link></li>
                        <li><Link href="#" className="hover:text-primary transition-colors">Contact</Link></li>
                    </ul>
                </div>
            </div>

            <div className="container px-6 pt-8 border-t border-border/40 flex flex-col md:flex-row items-center justify-between gap-6">
                <p className="text-xs text-muted-foreground font-medium">
                    © 2025 Flowtl AI. All rights reserved. Built with ❤️ in San Francisco.
                </p>
                <div className="flex items-center gap-8 text-xs font-bold uppercase tracking-tighter text-muted-foreground">
                    <span className="flex items-center gap-1.5"><div className="size-1.5 rounded-full bg-green-500" /> System Operational</span>
                    <span>v2.4.0-build</span>
                </div>
            </div>
        </footer>
    );
}
