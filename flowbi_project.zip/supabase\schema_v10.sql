
-- Update messages table to support multiple sources
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS source text DEFAULT 'airbnb' CHECK (source IN ('airbnb', 'whatsapp'));
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS platform_data jsonb; -- For source-specific metadata (e.g. phone number)
