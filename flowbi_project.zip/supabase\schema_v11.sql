
-- Add Confidence Gate fields to messages table
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS status text DEFAULT 'SENT' CHECK (status IN ('SENT', 'PENDING_APPROVAL', 'REJECTED', 'COMPLETED'));
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS original_platform text;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS external_guest_id text;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS confidence_score numeric;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS draft_content text;

-- Update existing messages to mark as SENT
UPDATE public.messages SET status = 'SENT' WHERE status IS NULL;
