
import { createClient } from '@/utils/supabase/server'
import { generateDeepSeekResponse } from '@/lib/openrouter'
import { sendSlackApprovalRequest, logToSlack } from '@/lib/slack'

export async function POST(request: Request) {
    const supabase = await createClient()
    const body = await request.json()

    const {
        property_id,
        content,
        sender_name,
        external_thread_id,
        external_guest_id,
        source = 'airbnb' // 'airbnb' or 'whatsapp'
    } = body

    if (!property_id || !content) {
        return new Response('Missing required fields', { status: 400 })
    }

    // 1. Fetch Property Context
    const { data: property, error: propError } = await supabase
        .from('properties')
        .select('*')
        .eq('id', property_id)
        .single()

    if (propError || !property) {
        return new Response('Property not found', { status: 404 })
    }

    // 2. Save Incoming Message to DB
    const { data: insertedMsg, error: msgError } = await supabase.from('messages').insert({
        property_id: property_id,
        sender_type: 'guest',
        sender_name: sender_name || (source === 'whatsapp' ? 'WhatsApp Guest' : 'Airbnb Guest'),
        content: content,
        external_thread_id: external_thread_id,
        external_guest_id: external_guest_id,
        original_platform: source,
        source: source,
        status: 'COMPLETED'
    }).select().single()

    if (msgError) console.error('Error saving message:', msgError)

    // 3. Automated AI Response Loop
    if (property.ai_automation_enabled) {
        const systemPrompt = `
            You are Flowbi, an elite AI concierge for "${property.name}". 
            Your tone is professional, minimalist, and high-end (Nvidia-style precision).
            You provide billionaire-level service quality to every guest.
            
            Wifi: ${property.wifi_name} / ${property.wifi_password}
            Check-in: ${property.check_in_instructions}
            Rules: ${property.house_rules}
            
            IMPORTANT: Output your response in valid JSON format only:
            {
                "reply": "Your helpful response string",
                "confidence": 0.0 to 1.0 (How accurately the properties info answers the guest)
            }
        `

        try {
            const aiRawResult = await generateDeepSeekResponse([
                { role: "system", content: systemPrompt },
                { role: "user", content: content }
            ])

            let aiResult;
            try {
                // Remove potential markdown code blocks from AI output
                const cleanJson = aiRawResult.replace(/```json|```/g, '').trim();
                aiResult = JSON.parse(cleanJson);
            } catch (e) {
                // Fallback if AI fails JSON
                aiResult = { reply: aiRawResult, confidence: 0.5 };
            }

            const confidenceScore = aiResult.confidence || 0.5;
            const aiReply = aiResult.reply;

            // 4. Branching Logic: Confidence Gate
            if (confidenceScore >= 0.85) {
                // High Confidence: Send Direct
                await logToSlack(`High-confidence reply sent for ${property.name} (${source})`);

                await supabase.from('messages').insert({
                    property_id: property_id,
                    sender_type: 'ai',
                    sender_name: 'AI Co-Host',
                    content: aiReply,
                    external_thread_id: external_thread_id,
                    source: source,
                    status: 'COMPLETED',
                    confidence_score: confidenceScore
                })

                return Response.json({ success: true, replied: aiReply, confidence: confidenceScore })
            } else {
                // Low Confidence: Request Approval
                const { data: pendingMsg } = await supabase.from('messages').insert({
                    property_id: property_id,
                    sender_type: 'ai',
                    sender_name: 'AI Co-Host (Draft)',
                    content: aiReply, // Draft content
                    draft_content: aiReply,
                    external_thread_id: external_thread_id,
                    external_guest_id: external_guest_id,
                    source: source,
                    status: 'PENDING_APPROVAL',
                    confidence_score: confidenceScore
                }).select().single()

                if (pendingMsg) {
                    await sendSlackApprovalRequest({
                        messageId: pendingMsg.id,
                        guestName: sender_name || 'Guest',
                        platform: source,
                        guestMessage: content,
                        draftReply: aiReply
                    });
                }

                return Response.json({
                    success: true,
                    info: 'Low confidence, routed to Slack for approval',
                    confidence: confidenceScore
                })
            }

        } catch (error) {
            console.error('AI Processing Error:', error)
            return Response.json({ success: false, error: 'Failed to process AI response' })
        }
    }

    return Response.json({ success: true, info: 'Message logged' })
}
