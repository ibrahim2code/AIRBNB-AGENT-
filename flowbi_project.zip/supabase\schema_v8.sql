
-- Add uniqueness constraint to prevent duplicate ical bookings
ALTER TABLE public.bookings 
ADD CONSTRAINT bookings_unique_external_property UNIQUE (property_id, external_id);
