
'use client'

import { Check } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { motion } from "framer-motion";

const plans = [
    {
        name: "Solo",
        price: "$29",
        description: "Perfect for individual hosts with up to 2 listings.",
        features: [
            "Up to 2 Properties",
            "24/7 AI Messaging",
            "Basic Guest Insights",
            "Standard Guest Vetting",
            "Maintenance Reminders",
            "Email Support"
        ],
        cta: "Start free trial",
        popular: false
    },
    {
        name: "Growth",
        price: "$99",
        description: "Best for growing hosts with multiple listings.",
        features: [
            "Up to 10 Properties",
            "WhatsApp Integration",
            "Automated Upsells (Late Check-outs)",
            "Priority AI Processing",
            "Advanced ID Verification",
            "Pricing Synchronization",
            "24/7 Priority Support"
        ],
        cta: "Scale Now",
        popular: true
    },
    {
        name: "Enterprise",
        price: "$349",
        description: "Designed for property management agencies.",
        note: "For portfolios larger than 20 properties, contact us for custom volume pricing.",
        features: [
            "Up to 20 Properties",
            "Custom API Access",
            "White-Label Options",
            "Dedicated Account Manager",
            "Multi-Team Access",
            "Audit Logs & Security"
        ],
        cta: "Contact Sales",
        popular: false
    }
];

export function Pricing() {
    return (
        <section id="pricing" className="py-24 sm:py-32 relative overflow-hidden">
            <div className="container px-6 relative z-10">
                <div className="text-center max-w-3xl mx-auto mb-20 space-y-6">
                    <motion.h2
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        className="text-4xl font-extrabold tracking-tight sm:text-5xl"
                    >
                        Plans for Every <span className="text-primary italic">Manager</span>
                    </motion.h2>
                    <p className="text-muted-foreground text-xl">
                        Flowbi scales with your portfolio. Start with one property, grow to thousands.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
                    {plans.map((plan: any, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: index * 0.1 }}
                            className={`relative p-8 rounded-3xl border-2 flex flex-col ${plan.popular
                                ? "border-primary bg-primary/5 shadow-2xl shadow-primary/10 scale-105 z-10"
                                : "border-border/40 bg-background/50"
                                }`}
                        >
                            {plan.popular && (
                                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-[10px] font-black uppercase tracking-widest px-4 py-1.5 rounded-full shadow-lg">
                                    Most Popular
                                </div>
                            )}

                            <div className="mb-8">
                                <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
                                <div className="flex items-baseline gap-1">
                                    <span className="text-4xl font-black">{plan.price}</span>
                                    <span className="text-muted-foreground text-sm font-semibold">/month</span>
                                </div>
                                <div className="mt-4">
                                    <p className="text-sm text-muted-foreground leading-relaxed">
                                        {plan.description}
                                    </p>
                                    {plan.note && (
                                        <p className="mt-2 text-[11px] font-medium text-primary/80 italic leading-snug">
                                            {plan.note}
                                        </p>
                                    )}
                                </div>
                            </div>

                            <div className="space-y-4 mb-10 flex-grow">
                                {plan.features.map((feature: string, i: number) => (
                                    <div key={i} className="flex items-center gap-3 text-sm font-medium">
                                        <div className="size-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                                            <Check className="size-3 text-primary" strokeWidth={3} />
                                        </div>
                                        <span>{feature}</span>
                                    </div>
                                ))}
                            </div>

                            <Button
                                variant={plan.popular ? "default" : "outline"}
                                className="w-full h-12 font-bold uppercase tracking-widest text-xs"
                            >
                                {plan.cta}
                            </Button>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
}
