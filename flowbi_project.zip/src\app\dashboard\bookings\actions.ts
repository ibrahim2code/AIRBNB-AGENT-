
'use server'

import { createClient } from '@/utils/supabase/server'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'

export async function addBooking(formData: FormData) {
    const supabase = await createClient()

    const propertyId = formData.get('property_id') as string
    const guestName = formData.get('guest_name') as string
    const checkIn = formData.get('check_in') as string
    const checkOut = formData.get('check_out') as string
    const totalPrice = formData.get('total_price') as string

    // Basic validation could go here

    const { error } = await supabase.from('bookings').insert({
        property_id: propertyId,
        guest_name: guestName,
        check_in_date: checkIn,
        check_out_date: checkOut,
        total_price: parseFloat(totalPrice) || 0,
        status: 'confirmed'
    })

    if (error) {
        console.error('Error adding booking:', error)
        return { error: 'Failed to add booking' }
    }

    revalidatePath(`/dashboard/properties/${propertyId}`)
    revalidatePath('/dashboard/bookings')
    return { success: true }
}

export async function deleteBooking(bookingId: string) {
    const supabase = await createClient()

    const { error } = await supabase
        .from('bookings')
        .delete()
        .eq('id', bookingId)

    if (error) {
        console.error('Error deleting booking', error)
        return { error: 'Failed to delete booking' }
    }

    revalidatePath('/dashboard/bookings')
    return { success: true }
}
