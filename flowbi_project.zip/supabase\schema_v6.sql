
-- Expand property knowledge base
ALTER TABLE public.properties
ADD COLUMN IF NOT EXISTS parking_instructions text,
ADD COLUMN IF NOT EXISTS neighborhood_tips text,
ADD COLUMN IF NOT EXISTS checkout_instructions text,
ADD COLUMN IF NOT EXISTS emergency_contacts jsonb DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS house_manual_link text;
