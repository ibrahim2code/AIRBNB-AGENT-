
const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.resolve(process.cwd(), '.env.local') });

async function getAccessToken() {
    console.log('--- Attempting Airbnb OAuth Token Exchange ---');

    // In many Airbnb implementations, the 'API Key' is actually the 'Client ID'
    const clientId = process.env.AIRBNB_API_KEY;
    const clientSecret = process.env.AIRBNB_API_SECRET;

    if (!clientId || !clientSecret) {
        console.error('❌ Error: Missing credentials in .env.local');
        return;
    }

    try {
        const response = await fetch('https://api.airbnb.com/v2/oauth2/access_token', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Airbnb-API-Key': clientId
            },
            body: JSON.stringify({
                client_id: clientId,
                client_secret: clientSecret,
                grant_type: 'client_credentials' // Standard for machine-to-machine
            })
        });

        console.log(`Status: ${response.status} ${response.statusText}`);
        const data = await response.json();

        if (response.ok) {
            console.log('✅ Token Exchange Successful!');
            console.log('Access Token:', data.access_token.substring(0, 10) + '...');
        } else {
            console.log('Error Detail:', JSON.stringify(data, null, 2));
        }
    } catch (error) {
        console.error('❌ Network Error:', error.message);
    }
}

getAccessToken();
