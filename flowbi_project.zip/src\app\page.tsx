
import { Navbar } from "@/components/layout/Navbar";
import { Hero } from "@/components/home/Hero";
import { Features } from "@/components/home/Features";
import { Pricing } from "@/components/home/Pricing";
import { Footer } from "@/components/layout/Footer";
import { createClient } from "@/utils/supabase/server";
import { logout } from "@/app/auth/actions";

export default async function Home() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  return (
    <main className="min-h-screen bg-background text-foreground selection:bg-primary/20">
      <Navbar user={user} logoutAction={logout} />

      {/* Background Glows for the whole page */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] right-[-10%] w-[40%] h-[40%] bg-primary/5 rounded-full blur-[150px]" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] bg-rose-500/5 rounded-full blur-[150px]" />
      </div>

      <div className="relative z-10">
        <Hero />

        <div className="bg-gradient-to-b from-transparent via-secondary/20 to-transparent">
          <Features />
        </div>

        <Pricing />

        <Footer />
      </div>
    </main>
  );
}
