
'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Link2, Building2, ExternalLink, ArrowRight, ShieldCheck } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'

// Mock data for the demonstration
const mockExternalListings = [
    { id: 'air_1', name: 'Luxury Beachfront Condo', address: '123 Ocean Drive' },
    { id: 'air_2', name: 'Mountain View Cabin', address: '456 Pine Ridge' },
    { id: 'air_3', name: 'Downtown Studio', address: '789 City Center' }
]

const mockLocalProperties = [
    { id: 'prop_1', name: 'My Beach Haven', address: '123 Ocean Dr' },
    { id: 'prop_2', name: 'Old Cabin', address: '456 Pine Ridge Rd' }
]

export default function ListingMappingPage() {
    const [mappings, setMappings] = useState<Record<string, string>>({})

    const handleMap = (externalId: string, localId: string) => {
        setMappings(prev => ({ ...prev, [externalId]: localId }))
    }

    return (
        <div className="max-w-6xl mx-auto py-12 px-6">
            <div className="mb-12 text-center">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-bold uppercase tracking-widest mb-4"
                >
                    <Link2 size={14} /> Step 2: Listing Mapping
                </motion.div>
                <h1 className="text-4xl font-black tracking-tight mb-4">Link Your Properties</h1>
                <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
                    Map your imported Airbnb listings to your local property profiles to enable automated messaging and sync.
                </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
                <div className="space-y-6">
                    <h2 className="text-xl font-bold flex items-center gap-2">
                        <ExternalLink className="text-primary" size={20} /> Imported from Airbnb
                    </h2>
                    {mockExternalListings.map((airbnb, idx) => (
                        <motion.div
                            key={airbnb.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: idx * 0.1 }}
                            className={`p-6 rounded-2xl border-2 transition-all ${mappings[airbnb.id] ? "border-green-500/50 bg-green-50/10" : "border-border/40 bg-background/50"
                                }`}
                        >
                            <div className="flex items-center justify-between mb-4">
                                <div>
                                    <h3 className="font-bold text-lg">{airbnb.name}</h3>
                                    <p className="text-sm text-muted-foreground">{airbnb.address}</p>
                                </div>
                                {mappings[airbnb.id] && (
                                    <div className="size-8 rounded-full bg-green-500 flex items-center justify-center text-white">
                                        <ShieldCheck size={18} />
                                    </div>
                                )}
                            </div>

                            {!mappings[airbnb.id] ? (
                                <div className="space-y-3">
                                    <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Connect to:</p>
                                    <div className="flex flex-wrap gap-2">
                                        {mockLocalProperties.map(local => (
                                            <Button
                                                key={local.id}
                                                size="sm"
                                                variant="outline"
                                                onClick={() => handleMap(airbnb.id, local.id)}
                                                className="rounded-full text-xs font-bold"
                                            >
                                                {local.name}
                                            </Button>
                                        ))}
                                        <Button size="sm" variant="ghost" className="rounded-full text-xs font-bold border-dashed border-2">
                                            + Create New
                                        </Button>
                                    </div>
                                </div>
                            ) : (
                                <div className="flex items-center gap-2 text-sm font-bold text-green-600">
                                    <ArrowRight size={16} /> Linked to {mockLocalProperties.find(p => p.id === mappings[airbnb.id])?.name}
                                    <Button
                                        variant="link"
                                        className="text-muted-foreground h-auto p-0 ml-auto"
                                        onClick={() => setMappings(prev => {
                                            const next = { ...prev };
                                            delete next[airbnb.id];
                                            return next;
                                        })}
                                    >
                                        Undo
                                    </Button>
                                </div>
                            )}
                        </motion.div>
                    ))}
                </div>

                <Card className="p-8 border-2 border-primary/20 bg-primary/5 sticky top-24">
                    <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
                        <Building2 className="text-primary" size={20} /> Why link?
                    </h2>
                    <ul className="space-y-4">
                        <li className="flex gap-3">
                            <div className="size-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                                <span className="text-xs font-bold text-primary">1</span>
                            </div>
                            <p className="text-sm text-muted-foreground leading-relaxed">
                                <span className="text-foreground font-bold italic">Enable AI Messaging</span>: The co-host needs to know which knowledge base to use for each inbox.
                            </p>
                        </li>
                        <li className="flex gap-3">
                            <div className="size-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                                <span className="text-xs font-bold text-primary">2</span>
                            </div>
                            <p className="text-sm text-muted-foreground leading-relaxed">
                                <span className="text-foreground font-bold italic">Smart Calendar Sync</span>: Automatically fetch bookings and update your availability.
                            </p>
                        </li>
                        <li className="flex gap-3">
                            <div className="size-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                                <span className="text-xs font-bold text-primary">3</span>
                            </div>
                            <p className="text-sm text-muted-foreground leading-relaxed">
                                <span className="text-foreground font-bold italic">Dynamic Pricing</span>: Our algorithms need to see guest demand across all your properties.
                            </p>
                        </li>
                    </ul>

                    <div className="mt-10 pt-8 border-t border-primary/10">
                        <Button className="w-full h-12 text-lg font-bold shadow-xl shadow-primary/20">
                            Continue to Dashboard
                            <ArrowRight className="ml-2" />
                        </Button>
                    </div>
                </Card>
            </div>
        </div>
    )
}
