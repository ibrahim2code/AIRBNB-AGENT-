
import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'
import { GoogleGenerativeAI } from '@google/generative-ai'
import { generateDeepSeekResponse } from '@/lib/openrouter'

export async function POST(request: Request) {
    const { message, property_id } = await request.json()

    // 1. Authenticate user
    const cookieStore = await cookies()
    const supabase = createServerClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL!,
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
        {
            cookies: {
                getAll() { return cookieStore.getAll() },
                setAll() { }
            },
        }
    )

    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
        return new Response('Unauthorized', { status: 401 })
    }

    // 2. Fetch Property Knowledge
    const { data: property } = await supabase
        .from('properties')
        .select('*')
        .eq('id', property_id)
        .single()

    if (!property) {
        return new Response('Property not found', { status: 404 })
    }

    const systemPromptContent = `
    You are Flowbi, an elite AI concierge.
    Your tone is professional, minimalist, and high-end—providing Nvidia-style precision and billionaire-level service.
    Your goal is to answer the guest's questions based strictly on the provided property information.
    
    Property Details:
    - Name: ${property.name}
    - Address: ${property.address}
    - Wifi Name: ${property.wifi_name || 'Not provided'}
    - Wifi Password: ${property.wifi_password || 'Not provided'}
    - Check-in Instructions: ${property.check_in_instructions || 'Not provided'}
    - Checkout Instructions: ${property.checkout_instructions || 'Not provided'}
    - Parking Instructions: ${property.parking_instructions || 'Not provided'}
    - Neighborhood Tips: ${property.neighborhood_tips || 'Not provided'}
    - House Manual Link: ${property.house_manual_link || 'Not provided'}
    - House Rules: ${property.house_rules || 'Not provided'}
    
    If the answer is not in the details provided, politely say you don't know and will contact the host.
    Keep answers concise, expert, and professional.
  `

    // 3. Try DeepSeek (via OpenRouter) first, fallback to Gemini
    try {
        if (process.env.OPENROUTER_API_KEY) {
            console.log('Using DeepSeek via OpenRouter...')
            const text = await generateDeepSeekResponse([
                { role: "system", content: systemPromptContent },
                { role: "user", content: message }
            ])
            return Response.json({ response: text })
        }

        // Fallback to Gemini if OpenRouter is not configured
        console.log('OpenRouter not configured, falling back to Gemini...')
        const apiKey = process.env.GEMINI_API_KEY
        if (!apiKey) {
            return Response.json({ response: "Error: No AI API keys configured (GEMINI_API_KEY or OPENROUTER_API_KEY missing)" })
        }

        const genAI = new GoogleGenerativeAI(apiKey)
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" })

        const result = await model.generateContent([
            `Context: ${systemPromptContent}\n\nUser Question: ${message}`
        ])

        const response = await result.response
        const text = response.text()

        return Response.json({ response: text })

    } catch (error: any) {
        console.error('AI Error:', error)
        if (error?.status === 429 || error?.message?.includes('429')) {
            return Response.json({ response: "AI Quota exceeded. Please try again in a minute." })
        }
        return Response.json({ response: "I'm having trouble thinking right now. Please check the API configuration." })
    }
}
