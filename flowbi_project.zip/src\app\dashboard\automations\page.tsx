
import { createClient } from '@/utils/supabase/server'
import { CreateAutomationForm } from '@/components/dashboard/CreateAutomationForm'
import { AutomationList } from '@/components/dashboard/AutomationList'
import { DashboardNav } from '@/components/dashboard/DashboardNav'

export default async function AutomationsPage() {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) return <div>Please log in</div>

    // Fetch properties
    const { data: properties } = await supabase
        .from('properties')
        .select('id, name')
        .eq('owner_id', user.id)

    // Fetch automations
    const { data: automations } = await supabase
        .from('automations')
        .select('*, properties(name)')
        // RLS handles filtering, but good to be explicit/ordered
        .order('created_at', { ascending: false })

    return (
        <div className="min-h-screen bg-gray-50">
            <DashboardNav />
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900">Automation Rules</h1>
                        <p className="text-sm text-gray-500 mt-1">Set up "If This Then That" rules for your guests</p>
                    </div>
                    <CreateAutomationForm properties={properties || []} />
                </div>

                <AutomationList automations={automations || []} />
            </div>
        </div>
    )
}
