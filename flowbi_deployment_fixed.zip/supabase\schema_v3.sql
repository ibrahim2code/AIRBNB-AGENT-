
alter table public.properties add column if not exists wifi_name text;

alter table public.properties add column if not exists wifi_password text;

alter table public.properties add column if not exists check_in_instructions text;

alter table public.properties add column if not exists house_rules text;
