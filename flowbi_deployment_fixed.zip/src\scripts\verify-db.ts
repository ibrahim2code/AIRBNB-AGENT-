
import dotenv from 'dotenv';
import path from 'path';

// Load .env.local explicitly
dotenv.config({ path: path.resolve(process.cwd(), '.env.local') });

async function checkTables() {
    const { supabase } = await import('../lib/supabase');

    console.log('Checking "properties" table...');
    try {
        // Try to select from properties.
        // Since RLS is on and we are using the anon key with NO user logged in,
        // we might get an empty array (if policy allows read) or just no error but 0 rows.
        // Actually, RLS policy says "Users can view their own properties" (using auth.uid() = owner_id).
        // Without a user, auth.uid() is null, so it returns nothing.
        // BUT, the important thing is we DON'T get "relation does not exist".
        const { data, error } = await supabase.from('properties').select('*');

        if (error) {
            console.log('Error:', error.message);
            console.log('Code:', error.code);
        } else {
            console.log('SUCCESS: Table "properties" exists and is queryable.');
            console.log('Data returned (should be empty):', data);
        }
    } catch (err) {
        console.error('Unexpected error:', err);
    }
}

checkTables();
