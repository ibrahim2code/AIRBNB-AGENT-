
'use client'

import { useState } from 'react'
import { toggleAIAutomation } from '@/app/dashboard/properties/actions'
import { Bot, Sparkles } from 'lucide-react'

export function AIAutomationToggle({
    propertyId,
    initialState
}: {
    propertyId: string,
    initialState: boolean
}) {
    const [isEnabled, setIsEnabled] = useState(initialState)
    const [loading, setLoading] = useState(false)

    const handleToggle = async () => {
        setLoading(true)
        const result = await toggleAIAutomation(propertyId, isEnabled)
        if (result.success) {
            setIsEnabled(!isEnabled)
        }
        setLoading(false)
    }

    return (
        <button
            onClick={handleToggle}
            disabled={loading}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold transition-all shadow-sm ${isEnabled
                    ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                    : 'bg-white text-gray-400 border border-gray-200 hover:border-gray-300 hover:text-gray-600'
                }`}
        >
            <Bot size={14} className={isEnabled ? 'animate-pulse' : ''} />
            {isEnabled ? 'AI Co-Host Active' : 'Enable AI Co-Host'}
            {isEnabled && <Sparkles size={10} className="text-amber-300" />}
        </button>
    )
}
