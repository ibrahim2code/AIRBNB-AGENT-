
const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.resolve(process.cwd(), '.env.local') });

async function testMethods() {
    const apiKey = process.env.AIRBNB_API_KEY;
    const url = 'https://api.airbnb.com/v2/listings/20685202';

    console.log(`Testing with key: ${apiKey.substring(0, 5)}...`);

    const methods = [
        { name: 'X-Airbnb-API-Key Header', headers: { 'X-Airbnb-API-Key': apiKey } },
        { name: 'key Query Param', url: `${url}?key=${apiKey}` },
        { name: '_key Query Param', url: `${url}?_key=${apiKey}` }
    ];

    for (const m of methods) {
        try {
            console.log(`--- Method: ${m.name} ---`);
            const response = await fetch(m.url || url, {
                method: 'GET',
                headers: m.headers || {}
            });
            console.log(`Status: ${response.status}`);
            const text = await response.text();
            if (response.status === 200) {
                console.log('✅ SUCCESS!');
                break;
            } else {
                console.log('Result:', text.substring(0, 100));
            }
        } catch (e) {
            console.log('Error:', e.message);
        }
    }
}

testMethods();
