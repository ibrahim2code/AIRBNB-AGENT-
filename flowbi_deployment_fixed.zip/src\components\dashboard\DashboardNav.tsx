
'use client'


import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, Calendar, Settings, LogOut, Bot } from 'lucide-react'
import { logout } from '@/app/auth/actions'


export function DashboardNav() {
    const pathname = usePathname()

    const links = [
        { href: '/dashboard', label: 'Properties', icon: Home },
        { href: '/dashboard/inbox', label: 'Inbox', icon: Calendar },
        { href: '/dashboard/bookings', label: 'Bookings', icon: Calendar },
        { href: '/dashboard/automations', label: 'Automations', icon: Settings },
        { href: '/dashboard/settings', label: 'Co-Host', icon: Bot },
    ]

    return (
        <nav className="bg-white shadow">
            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <div className="flex h-16 justify-between">
                    <div className="flex">
                        <div className="flex flex-shrink-0 items-center">
                            <span className="text-xl font-bold text-indigo-600">AirbnbSaaS</span>
                        </div>
                        <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
                            {links.map((link) => {
                                const Icon = link.icon
                                const isActive = pathname === link.href
                                return (
                                    <Link
                                        key={link.href}
                                        href={link.href}
                                        className={`inline-flex items-center border-b-2 px-1 pt-1 text-sm font-medium ${isActive
                                            ? 'border-indigo-500 text-gray-900'
                                            : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                                            }`}
                                    >
                                        <Icon size={16} className="mr-2" />
                                        {link.label}
                                    </Link>
                                )
                            })}
                        </div>
                    </div>
                    <div className="flex items-center">
                        <form action={logout}>
                            <button className="text-gray-500 hover:text-gray-700">
                                <LogOut size={20} />
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </nav>
    )
}
