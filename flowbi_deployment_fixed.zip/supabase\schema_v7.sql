
-- Create bookings table for calendar sync
CREATE TABLE IF NOT EXISTS public.bookings (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    property_id uuid NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
    guest_name text,
    check_in date NOT NULL,
    check_out date NOT NULL,
    status text DEFAULT 'confirmed', -- confirmed, cancelled, pending
    source text DEFAULT 'ical', -- ical, manual, airbnb_api
    external_id text, -- ID from Airbnb/VRBO iCal
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    
    PRIMARY KEY (id)
);

ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view bookings for their properties" ON bookings
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM properties 
            WHERE properties.id = bookings.property_id 
            AND properties.owner_id = auth.uid()
        )
    );

-- Add ical_link column to properties if not exists
ALTER TABLE public.properties ADD COLUMN IF NOT EXISTS ical_link text;
ALTER TABLE public.properties ADD COLUMN IF NOT EXISTS last_sync_at timestamp with time zone;
