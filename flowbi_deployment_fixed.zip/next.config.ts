import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  serverExternalPackages: ["@slack/web-api", "@slack/bolt"],
};

export default nextConfig;
