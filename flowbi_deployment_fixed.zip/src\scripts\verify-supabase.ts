
import dotenv from 'dotenv';
import path from 'path';

// Load .env.local explicitly
dotenv.config({ path: path.resolve(process.cwd(), '.env.local') });

async function checkConnection() {
    // Dynamic import so env vars are loaded first
    const { supabase } = await import('../lib/supabase');

    console.log('Checking Supabase connection...');
    try {
        const { data, error } = await supabase.from('test').select('*').limit(1);

        if (error) {
            console.log('Connection attempt finished.');
            // PGRST204 means table not found, which proves we hit the DB
            if (error.code === 'PGRST204' || error.message.includes('relation "public.test" does not exist')) {
                console.log('SUCCESS: Connected to Supabase! (Table "test" missing as expected)');
            } else {
                console.log('Connection error:', error.message);
                console.log('Error Code:', error.code);
            }
        } else {
            console.log('SUCCESS: Data received:', data);
        }
    } catch (err) {
        console.error('Unexpected error:', err);
    }
}

checkConnection();
