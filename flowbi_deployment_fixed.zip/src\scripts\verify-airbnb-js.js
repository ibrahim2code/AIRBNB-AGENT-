
const dotenv = require('dotenv');
const path = require('path');

// Load .env.local
dotenv.config({ path: path.resolve(process.cwd(), '.env.local') });

async function verifyAirbnbAPI() {
    console.log('--- Testing Airbnb API Connectivity (JS) ---');
    const apiKey = process.env.AIRBNB_API_KEY;

    if (!apiKey) {
        console.error('❌ Error: Missing AIRBNB_API_KEY in .env.local');
        return;
    }

    console.log(`Using API Key: ${apiKey.substring(0, 5)}...`);

    try {
        // Test a public listing fetch with the API Key
        const response = await fetch('https://api.airbnb.com/v2/listings/20685202', {
            method: 'GET',
            headers: {
                'X-Airbnb-API-Key': apiKey,
                'Content-Type': 'application/json'
            }
        });

        console.log(`Response Status: ${response.status} ${response.statusText}`);

        if (response.status === 200 || response.status === 404) {
            console.log('✅ Success: The API connection is open and the key is being sent correctly.');
        } else {
            const text = await response.text();
            console.log('Detail:', text.substring(0, 100));
        }

    } catch (error) {
        console.error('❌ Network Error:', error.message);
    }
}

verifyAirbnbAPI();
