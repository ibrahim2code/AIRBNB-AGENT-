
'use client'

import { useState } from 'react'
import { connectAirbnbAccount, disconnectAirbnbAccount } from '@/app/dashboard/settings/connection-actions'
import { CheckCircle2, XCircle, ExternalLink, RefreshCw, Bot } from 'lucide-react'

interface AirbnbConnectProps {
    isConnected: boolean;
    connectedAt: string | null;
}

export default function AirbnbConnect({ isConnected, connectedAt }: AirbnbConnectProps) {
    const [loading, setLoading] = useState(false)

    const handleConnect = async () => {
        setLoading(true)
        const result = await connectAirbnbAccount()
        if (result.error) alert(result.error)
        setLoading(false)
    }

    const handleDisconnect = async () => {
        if (!confirm('Are you sure you want to disconnect your Airbnb account?')) return
        setLoading(true)
        const result = await disconnectAirbnbAccount()
        if (result.error) alert(result.error)
        setLoading(false)
    }

    return (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="p-6 sm:p-8">
                <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-4">
                        <div className={`p-3 rounded-xl ${isConnected ? 'bg-green-50 text-green-600' : 'bg-orange-50 text-orange-600'}`}>
                            {isConnected ? <CheckCircle2 size={28} /> : <Bot size={28} />}
                        </div>
                        <div>
                            <h3 className="text-xl font-bold text-gray-900 leading-none mb-2">Airbnb Official Integration</h3>
                            <p className="text-sm text-gray-500">
                                {isConnected
                                    ? `Connected on ${new Date(connectedAt!).toLocaleDateString()}`
                                    : 'Connect your account to enable DeepSeek AI Co-Host'}
                            </p>
                        </div>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${isConnected ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
                        }`}>
                        {isConnected ? 'Active' : 'Offline'}
                    </div>
                </div>

                {isConnected ? (
                    <div className="space-y-4">
                        <div className="bg-green-50/50 rounded-xl p-4 border border-green-100/50">
                            <p className="text-sm text-green-800 flex items-center gap-2">
                                <CheckCircle2 size={16} />
                                Authenticated: DeepSeek can now respond to your Airbnb guests.
                            </p>
                        </div>
                        <button
                            onClick={handleDisconnect}
                            disabled={loading}
                            className="w-full py-3 px-4 bg-white border border-red-200 text-red-600 rounded-xl text-sm font-semibold hover:bg-red-50 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                        >
                            {loading && <RefreshCw className="animate-spin" size={16} />}
                            Disconnect Airbnb Account
                        </button>
                    </div>
                ) : (
                    <div className="space-y-6">
                        <ul className="space-y-3">
                            <li className="flex items-start gap-3 text-sm text-gray-600">
                                <div className="mt-1 flex-shrink-0 w-1.5 h-1.5 rounded-full bg-orange-500" />
                                Sync listings and availability in real-time
                            </li>
                            <li className="flex items-start gap-3 text-sm text-gray-600">
                                <div className="mt-1 flex-shrink-0 w-1.5 h-1.5 rounded-full bg-orange-500" />
                                Automated AI replies via DeepSeek-V3
                            </li>
                            <li className="flex items-start gap-3 text-sm text-gray-600">
                                <div className="mt-1 flex-shrink-0 w-1.5 h-1.5 rounded-full bg-orange-500" />
                                Unified inbox for all platforms
                            </li>
                        </ul>
                        <button
                            onClick={handleConnect}
                            disabled={loading}
                            className="w-full py-4 px-6 bg-gradient-to-r from-orange-500 to-rose-500 text-white rounded-xl text-md font-bold hover:shadow-lg hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 disabled:opacity-50 shadow-md shadow-orange-200"
                        >
                            {loading ? <RefreshCw className="animate-spin" size={20} /> : <ExternalLink size={20} />}
                            Connect Airbnb Account
                        </button>
                    </div>
                )}
            </div>
            <div className="bg-gray-50/80 px-6 sm:px-8 py-4 border-t border-gray-100">
                <p className="text-xs text-center text-gray-400">
                    Official Partner Integration. No password shared. Secure OAuth2 connection.
                </p>
            </div>
        </div>
    )
}
