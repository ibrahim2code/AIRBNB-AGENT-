
'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Send, User, Bot } from 'lucide-react'

// Passing properties so we can select which 'brain' we are talking to
export function AgentSimulator({ properties }: { properties: any[] }) {
    const [selectedPropId, setSelectedPropId] = useState(properties[0]?.id || '')
    const [message, setMessage] = useState('')
    const [chatLog, setChatLog] = useState<{ role: 'user' | 'agent', text: string }[]>([])
    const [isLoading, setIsLoading] = useState(false)

    async function handleSend() {
        if (!message.trim() || !selectedPropId) return

        // Add user message
        const userMsg = message
        setChatLog(prev => [...prev, { role: 'user', text: userMsg }])
        setMessage('')
        setIsLoading(true)

        try {
            const res = await fetch('/api/agent', {
                method: 'POST',
                body: JSON.stringify({
                    message: userMsg,
                    property_id: selectedPropId
                })
            })
            const data = await res.json()

            // Add agent response
            setChatLog(prev => [...prev, { role: 'agent', text: data.response }])

        } catch (err) {
            setChatLog(prev => [...prev, { role: 'agent', text: "Error connecting to the agent." }])
        }

        setIsLoading(false)
    }

    if (properties.length === 0) return null

    return (
        <Card className="flex flex-col h-[500px] bg-white border border-gray-200 shadow-xl overflow-hidden">
            {/* Header */}
            <div className="p-4 border-b border-gray-100 bg-indigo-600 text-white flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <Bot size={20} />
                    <span className="font-semibold">Co-Host Simulator</span>
                </div>

                <select
                    className="bg-indigo-700 text-white text-sm border-none rounded px-2 py-1 outline-none"
                    value={selectedPropId}
                    onChange={(e) => {
                        setSelectedPropId(e.target.value)
                        setChatLog([]) // Clear chat on property switch
                    }}
                >
                    {properties.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
            </div>

            {/* Chat Area */}
            <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-gray-50">
                {chatLog.length === 0 && (
                    <div className="text-center text-gray-400 text-sm mt-20">
                        <p>Select a property and send a message.</p>
                        <p>Try asking: "What is the Wifi password?"</p>
                    </div>
                )}

                {chatLog.map((msg, idx) => (
                    <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] rounded-lg px-4 py-2 text-sm ${msg.role === 'user'
                                ? 'bg-indigo-600 text-white rounded-br-none'
                                : 'bg-white border border-gray-200 text-gray-800 rounded-bl-none shadow-sm'
                            }`}>
                            {msg.text}
                        </div>
                    </div>
                ))}

                {isLoading && (
                    <div className="flex justify-start">
                        <div className="bg-gray-200 rounded-lg px-4 py-2 text-xs text-gray-500 animate-pulse">
                            Thinking...
                        </div>
                    </div>
                )}
            </div>

            {/* Input Area */}
            <div className="p-4 bg-white border-t border-gray-100 flex gap-2">
                <input
                    className="flex-1 border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:border-indigo-500"
                    placeholder="Type a message as a guest..."
                    value={message}
                    onChange={e => setMessage(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleSend()}
                />
                <Button size="icon" onClick={handleSend} disabled={isLoading || !message.trim()}>
                    <Send size={18} />
                </Button>
            </div>
        </Card>
    )
}
