
-- Update profiles table to track Airbnb connection
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS airbnb_connected boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS airbnb_connected_at timestamp with time zone;

-- Update properties to include an external ID mapping (for real Airbnb listing IDs)
ALTER TABLE public.properties
ADD COLUMN IF NOT EXISTS external_id text;
