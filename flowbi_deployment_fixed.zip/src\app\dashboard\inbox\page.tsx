
import { createClient } from '@/utils/supabase/server'
import { DashboardNav } from '@/components/dashboard/DashboardNav'
import { ChatInterface } from '@/components/dashboard/ChatInterface'

export default async function InboxPage() {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) return <div>Please log in</div>

    // Fetch properties for the dropdown
    const { data: properties } = await supabase
        .from('properties')
        .select('id, name')
        .eq('owner_id', user.id)

    return (
        <div className="min-h-screen bg-white">
            <DashboardNav />
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <div className="mb-8">
                    <h1 className="text-2xl font-bold text-gray-900">Unified Inbox</h1>
                    <p className="text-sm text-gray-500 mt-1">Manage guest communications across all properties</p>
                </div>

                <ChatInterface properties={properties || []} />
            </div>
        </div>
    )
}
