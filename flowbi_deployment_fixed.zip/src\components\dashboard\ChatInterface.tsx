'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/utils/supabase/client'
import { Send, User, Bot, AlertCircle, MessageCircle, Phone, Smartphone } from 'lucide-react'

export function ChatInterface({ properties }: { properties: any[] }) {
    const [selectedProperty, setSelectedProperty] = useState(properties[0]?.id || '')
    const [messages, setMessages] = useState<any[]>([])
    const [loading, setLoading] = useState(false)
    const [simulating, setSimulating] = useState(false)
    const [mockMessage, setMockMessage] = useState('')

    const supabase = createClient()

    useEffect(() => {
        if (!selectedProperty) return

        const fetchMessages = async () => {
            const { data } = await supabase
                .from('messages')
                .select('*')
                .eq('property_id', selectedProperty)
                .order('created_at', { ascending: true })

            setMessages(data || [])
        }

        fetchMessages()

        // Subscribe to new messages
        const channel = supabase
            .channel('messages_channel')
            .on('postgres_changes', {
                event: 'INSERT',
                schema: 'public',
                table: 'messages',
                filter: `property_id=eq.${selectedProperty}`
            }, (payload: any) => {
                setMessages((prev) => [...prev, payload.new])
            })
            .subscribe()

        return () => {
            supabase.removeChannel(channel)
        }
    }, [selectedProperty, supabase])

    const handleSimulateMessage = async (source: 'airbnb' | 'whatsapp') => {
        if (!mockMessage || !selectedProperty) return
        setSimulating(true)

        try {
            const res = await fetch('/api/webhooks/unified', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    property_id: selectedProperty,
                    content: mockMessage,
                    sender_name: 'John Doe (Guest)',
                    external_thread_id: 'unified_thread_789',
                    source: source
                })
            })

            if (res.ok) {
                setMockMessage('')
            }
        } catch (error) {
            console.error('Simulation failed:', error)
        } finally {
            setSimulating(false)
        }
    }

    return (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[750px]">
            {/* Sidebar: Properties */}
            <div className="bg-[#FFFDF9] p-4 rounded-3xl border border-[#E8DCCF] lg:col-span-1 shadow-sm">
                <h3 className="text-[10px] font-black text-[#5C4B4B] uppercase tracking-widest mb-6 opacity-60">Properties</h3>
                <div className="space-y-2">
                    {properties.map((p) => (
                        <button
                            key={p.id}
                            onClick={() => setSelectedProperty(p.id)}
                            className={`w-full text-left px-4 py-3 rounded-2xl text-sm font-bold transition-all ${selectedProperty === p.id
                                ? 'bg-[#FF4F00] text-white shadow-lg shadow-orange-500/20'
                                : 'text-[#201515] hover:bg-[#FFF3E6]'
                                }`}
                        >
                            {p.name}
                        </button>
                    ))}
                </div>
            </div>

            {/* Main: Chat area */}
            <div className="flex flex-col bg-[#FFFDF9] rounded-3xl border border-[#E8DCCF] lg:col-span-3 overflow-hidden shadow-xl shadow-black/5">
                <div className="flex-1 overflow-y-auto p-8 space-y-6 bg-cream/20">
                    {messages.length === 0 ? (
                        <div className="flex flex-col items-center justify-center h-full text-[#5C4B4B] opacity-30">
                            <Bot size={64} className="mb-4" strokeWidth={1} />
                            <p className="font-bold">No messages in this unified thread.</p>
                        </div>
                    ) : (
                        messages.map((m) => (
                            <div key={m.id} className={`flex ${m.sender_type === 'guest' ? 'justify-start' : 'justify-end'}`}>
                                <div className={`group relative max-w-[80%] rounded-3xl px-5 py-3 text-sm transition-all ${m.sender_type === 'guest'
                                    ? 'bg-white border border-[#E8DCCF] text-[#201515] rounded-tl-none shadow-sm'
                                    : m.sender_type === 'ai'
                                        ? 'bg-[#FF4F00] text-white rounded-tr-none shadow-orange-500/20 shadow-lg'
                                        : 'bg-[#2B2358] text-white rounded-tr-none'
                                    }`}>
                                    <div className="flex items-center justify-between gap-4 mb-2 opacity-70 text-[10px] uppercase font-black tracking-widest">
                                        <div className="flex items-center gap-1.5">
                                            {m.sender_type === 'guest' ? <User size={10} /> : <Bot size={10} />}
                                            {m.sender_name}
                                        </div>
                                        {/* SOURCE ICON */}
                                        <div className="flex items-center gap-1 text-[9px] font-black px-1.5 py-0.5 rounded bg-black/5 border border-black/5">
                                            {m.source === 'whatsapp' ? (
                                                <><MessageCircle size={10} className="text-green-500" /> WhatsApp</>
                                            ) : (
                                                <><Smartphone size={10} className="text-[#FF4F00]" /> Airbnb</>
                                            )}
                                        </div>
                                    </div>
                                    <div className="whitespace-pre-wrap leading-relaxed font-medium">{m.content}</div>
                                    <div className="text-[9px] mt-2 opacity-50 font-bold">
                                        {new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                    </div>
                                </div>
                            </div>
                        ))
                    )}
                </div>

                {/* Input: Unified Simulator */}
                <div className="p-6 bg-white border-t border-gray-100">
                    <div className="flex flex-col gap-4">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 text-[10px] font-black text-amber-600 bg-amber-50 px-3 py-1.5 rounded-full border border-amber-100 uppercase tracking-widest">
                                <AlertCircle size={14} />
                                Unified Simulator
                            </div>
                            <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Testing Thread Consistency</div>
                        </div>

                        <div className="flex gap-3">
                            <input
                                type="text"
                                value={mockMessage}
                                onChange={(e) => setMockMessage(e.target.value)}
                                placeholder="Simulate guest message..."
                                className="flex-1 bg-[#FFF3E6]/50 border border-[#E8DCCF] focus:ring-2 focus:ring-[#FF4F00] focus:bg-white rounded-2xl px-5 py-3 text-sm outline-none transition-all font-medium"
                                onKeyPress={(e) => e.key === 'Enter' && handleSimulateMessage('airbnb')}
                            />

                            <div className="flex gap-2">
                                <button
                                    onClick={() => handleSimulateMessage('airbnb')}
                                    disabled={simulating || !mockMessage}
                                    title="Send via Airbnb"
                                    className="bg-white border-2 border-[#E8DCCF] hover:border-[#FF4F00] text-[#FF4F00] p-3 rounded-2xl transition-all disabled:opacity-50 active:scale-95 flex items-center gap-2 font-bold text-xs uppercase"
                                >
                                    <Smartphone size={18} />
                                    Airbnb
                                </button>
                                <button
                                    onClick={() => handleSimulateMessage('whatsapp')}
                                    disabled={simulating || !mockMessage}
                                    title="Send via WhatsApp"
                                    className="bg-green-500 hover:bg-green-600 text-white p-3 rounded-2xl transition-all disabled:opacity-50 active:scale-95 flex items-center gap-2 font-bold text-xs uppercase shadow-lg shadow-green-500/20"
                                >
                                    <MessageCircle size={18} />
                                    WhatsApp
                                </button>
                            </div>
                        </div>
                        <p className="text-[10px] text-muted-foreground font-medium italic opacity-60">
                            Flowbi automatically merges messages from both platforms into this single property thread.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    )
}
