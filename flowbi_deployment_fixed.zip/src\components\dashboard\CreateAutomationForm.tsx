
'use client'

import { useState } from 'react'
import { createAutomation } from '@/app/dashboard/automations/actions'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Plus, X, Zap } from 'lucide-react'

export function CreateAutomationForm({ properties }: { properties: any[] }) {
    const [isOpen, setIsOpen] = useState(false)
    const [isSubmitting, setIsSubmitting] = useState(false)

    async function handleSubmit(formData: FormData) {
        setIsSubmitting(true)
        await createAutomation(formData)
        setIsSubmitting(false)
        setIsOpen(false)
    }

    if (!isOpen) {
        return (
            <Button onClick={() => setIsOpen(true)} className="flex items-center gap-2">
                <Plus size={16} /> New Automation
            </Button>
        )
    }

    if (properties.length === 0) {
        return (
            <Card className="p-4 bg-yellow-50 border border-yellow-200">
                <div className="flex justify-between items-center">
                    <span className="text-sm text-yellow-800">Add a property first to create automations.</span>
                    <button onClick={() => setIsOpen(false)}><X size={16} /></button>
                </div>
            </Card>
        )
    }

    return (
        <Card className="p-6 mb-6 bg-white border border-gray-200 shadow-sm">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                    <Zap size={18} className="text-indigo-600" /> Create Rule
                </h3>
                <button onClick={() => setIsOpen(false)} className="text-gray-500 hover:text-gray-700">
                    <X size={20} />
                </button>
            </div>
            <form action={handleSubmit} className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700">Property</label>
                    <select
                        name="property_id"
                        required
                        className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:ring-indigo-500 bg-white"
                    >
                        {properties.map(p => (
                            <option key={p.id} value={p.id}>{p.name}</option>
                        ))}
                    </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700">When...</label>
                        <select
                            name="trigger_type"
                            required
                            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:ring-indigo-500 bg-white"
                        >
                            <option value="booking_created">New Booking Created</option>
                            <option value="check_in">Guest Checks In</option>
                            <option value="check_out">Guest Checks Out</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Then...</label>
                        <select
                            name="action_type"
                            required
                            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:ring-indigo-500 bg-white"
                        >
                            <option value="send_email">Send Email</option>
                            <option value="send_sms">Send SMS</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700">Message Template</label>
                    <textarea
                        name="template_content"
                        required
                        rows={4}
                        className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:ring-indigo-500"
                        placeholder="Hi {guest_name}, thanks for booking with us! Here are the check-in instructions..."
                    />
                    <p className="mt-1 text-xs text-gray-500">Available variables: {'{guest_name}'}, {'{property_name}'}, {'{check_in}'}</p>
                </div>

                <div className="flex justify-end gap-2 pt-2">
                    <Button type="button" variant="secondary" onClick={() => setIsOpen(false)}>
                        Cancel
                    </Button>
                    <Button type="submit" disabled={isSubmitting}>
                        {isSubmitting ? 'Saving...' : 'Save Automation'}
                    </Button>
                </div>
            </form>
        </Card>
    )
}
