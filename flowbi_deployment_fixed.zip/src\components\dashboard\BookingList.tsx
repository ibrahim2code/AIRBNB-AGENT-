
import { format } from 'date-fns'
import { Calendar, User, DollarSign, ArrowRight } from 'lucide-react'
import { Card } from '@/components/ui/Card'

export function BookingList({ bookings }: { bookings: any[] }) {

    if (!bookings || bookings.length === 0) {
        return (
            <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
                <Calendar className="mx-auto h-12 w-12 text-gray-300" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">No bookings found</h3>
                <p className="mt-1 text-sm text-gray-500">Create a new reservation to get started.</p>
            </div>
        )
    }

    return (
        <div className="space-y-4">
            {bookings.map((booking) => (
                <Card key={booking.id} className="p-4 hover:shadow-md transition-shadow bg-white border border-gray-200">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">

                        {/* Left Side: Info */}
                        <div className="flex items-start gap-4">
                            <div className="p-2 bg-indigo-50 rounded-lg">
                                <Calendar className="h-6 w-6 text-indigo-600" />
                            </div>
                            <div>
                                <h4 className="text-sm font-semibold text-gray-900">
                                    {booking.guest_name}
                                </h4>
                                <p className="text-xs text-gray-500 flex items-center gap-1 mt-1">
                                    {booking.properties?.name || 'Unknown Property'}
                                </p>
                                <div className="flex items-center gap-2 mt-2 text-sm text-gray-600">
                                    <span>{format(new Date(booking.check_in_date), 'MMM d, yyyy')}</span>
                                    <ArrowRight size={14} className="text-gray-400" />
                                    <span>{format(new Date(booking.check_out_date), 'MMM d, yyyy')}</span>
                                </div>
                            </div>
                        </div>

                        {/* Right Side: Price & Status */}
                        <div className="flex flex-col items-end gap-2">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${booking.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                                    booking.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                                        'bg-yellow-100 text-yellow-800'
                                }`}>
                                {booking.status}
                            </span>
                            <div className="flex items-center font-medium text-gray-900">
                                <DollarSign size={16} className="text-gray-400" />
                                {booking.total_price}
                            </div>
                        </div>

                    </div>
                </Card>
            ))}
        </div>
    )
}
