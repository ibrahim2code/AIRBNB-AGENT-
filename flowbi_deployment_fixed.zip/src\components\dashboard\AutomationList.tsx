
'use client'

import { Zap, Mail, MessageSquare, Trash2, Power } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { toggleAutomation, deleteAutomation } from '@/app/dashboard/automations/actions'
import { Button } from '@/components/ui/Button'

export function AutomationList({ automations }: { automations: any[] }) {

    if (!automations || automations.length === 0) {
        return (
            <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
                <Zap className="mx-auto h-12 w-12 text-gray-300" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">No automations set up</h3>
                <p className="mt-1 text-sm text-gray-500">Create rules to save time managing guests.</p>
            </div>
        )
    }

    return (
        <div className="space-y-4">
            {automations.map((auto) => (
                <Card key={auto.id} className={`p-4 transition-all border ${auto.is_active ? 'border-indigo-100 bg-white' : 'border-gray-200 bg-gray-50 opacity-75'}`}>
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">

                        <div className="flex items-start gap-4">
                            <div className={`p-2 rounded-lg ${auto.is_active ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-200 text-gray-500'}`}>
                                {auto.action_type === 'send_email' ? <Mail size={24} /> : <MessageSquare size={24} />}
                            </div>
                            <div>
                                <div className="flex items-center gap-2">
                                    <span className="text-sm font-bold text-gray-900 uppercase tracking-wider">
                                        IF {auto.trigger_type.replace('_', ' ')}
                                    </span>
                                    <span className="text-gray-400">→</span>
                                    <span className="text-sm font-bold text-indigo-600 uppercase tracking-wider">
                                        {auto.action_type.replace('_', ' ')}
                                    </span>
                                </div>
                                <p className="text-xs text-gray-500 mt-1">
                                    Property: {auto.properties?.name || 'Unknown'}
                                </p>
                                <p className="text-sm text-gray-600 mt-2 line-clamp-1 italic">
                                    "{auto.template_content}"
                                </p>
                            </div>
                        </div>

                        <div className="flex items-center gap-2">
                            <form action={async () => await toggleAutomation(auto.id, auto.is_active)}>
                                <Button
                                    variant="secondary"
                                    size="sm"
                                    className={auto.is_active ? "text-green-600 hover:text-green-700" : "text-gray-500"}
                                    title={auto.is_active ? "Deactivate" : "Activate"}
                                >
                                    <Power size={16} />
                                </Button>
                            </form>
                            <form action={async () => await deleteAutomation(auto.id)}>
                                <Button variant="secondary" size="sm" className="text-red-500 hover:text-red-700 hover:bg-red-50">
                                    <Trash2 size={16} />
                                </Button>
                            </form>
                        </div>

                    </div>
                </Card>
            ))}
        </div>
    )
}
