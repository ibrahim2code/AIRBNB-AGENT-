
'use client'

import { Button } from "@/components/ui/Button";
import Link from "next/link";
import { ArrowRight, Bot, Sparkles, Building2, ShieldCheck, Zap } from "lucide-react";
import { motion } from "framer-motion";

export function Hero() {
    return (
        <section className="relative overflow-hidden pt-32 pb-16 md:pt-48 md:pb-32 bg-background">
            {/* Ambient Background Elements */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-7xl z-0 pointer-events-none">
                <motion.div
                    animate={{
                        scale: [1, 1.2, 1],
                        opacity: [0.3, 0.5, 0.3]
                    }}
                    transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
                    className="absolute top-[10%] left-[10%] w-[500px] h-[500px] bg-primary/10 rounded-full blur-[120px]"
                />
                <motion.div
                    animate={{
                        scale: [1.2, 1, 1.2],
                        opacity: [0.2, 0.4, 0.2]
                    }}
                    transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
                    className="absolute bottom-[10%] right-[10%] w-[600px] h-[600px] bg-rose-500/10 rounded-full blur-[120px]"
                />
            </div>

            <div className="container relative z-10 px-4 md:px-6 flex flex-col items-center text-center space-y-10">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="inline-flex items-center rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 text-sm font-semibold text-primary backdrop-blur-md shadow-sm"
                >
                    <Sparkles className="size-4 mr-2" />
                    <span>Next Generation Airbnb Automation</span>
                </motion.div>

                <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8 }}
                    className="max-w-4xl mx-auto text-center"
                >
                    <h1 className="text-6xl md:text-8xl font-black tracking-tighter mb-8 leading-[0.9]">
                        The AI <span className="text-primary italic">Brain</span> for your <span className="underline decoration-primary/30">Rentals.</span>
                    </h1>
                    <motion.p
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2, duration: 0.8 }}
                        className="text-muted-foreground text-xl md:text-2xl max-w-2xl mx-auto leading-relaxed"
                    >
                        Meet <span className="text-foreground font-bold">Flowbi</span>. The elite AI concierge that handles your guest communication, syncing, and logistics with technical precision.
                    </motion.p>
                    <p className="max-w-[48rem] mx-auto leading-relaxed text-muted-foreground sm:text-2xl sm:leading-9">
                        Scale your short-term rental business without the 24/7 grind.
                        Let our DeepSeek-powered agents handle messaging, pricing, and guests.
                    </p>
                </motion.div>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.2 }}
                    className="flex flex-col sm:flex-row gap-5 w-full sm:w-auto"
                >
                    <Button size="xl" className="h-14 px-10 text-lg font-bold shadow-xl shadow-primary/20 hover:scale-105 transition-transform active:scale-95">
                        Get Started Free
                        <ArrowRight className="ml-2 size-5" />
                    </Button>
                    <Button variant="outline" size="xl" className="h-14 px-10 text-lg font-bold border-2 backdrop-blur-md hover:bg-secondary/50">
                        Watch Demo
                    </Button>
                </motion.div>

                {/* Social Proof / Stats */}
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 1, delay: 0.5 }}
                    className="grid grid-cols-2 md:grid-cols-4 gap-8 pt-12 border-t border-border/40 w-full max-w-4xl"
                >
                    <div className="flex flex-col items-center space-y-1">
                        <span className="text-3xl font-bold">90%</span>
                        <span className="text-sm text-muted-foreground uppercase tracking-widest font-semibold">Auto-Replies</span>
                    </div>
                    <div className="flex flex-col items-center space-y-1">
                        <span className="text-3xl font-bold">24/7</span>
                        <span className="text-sm text-muted-foreground uppercase tracking-widest font-semibold">Uptime</span>
                    </div>
                    <div className="flex flex-col items-center space-y-1">
                        <span className="text-3xl font-bold">15m</span>
                        <span className="text-sm text-muted-foreground uppercase tracking-widest font-semibold">Setup Time</span>
                    </div>
                    <div className="flex flex-col items-center space-y-1">
                        <span className="text-3xl font-bold">10x</span>
                        <span className="text-sm text-muted-foreground uppercase tracking-widest font-semibold">Efficiency</span>
                    </div>
                </motion.div>
            </div>
        </section>
    );
}
