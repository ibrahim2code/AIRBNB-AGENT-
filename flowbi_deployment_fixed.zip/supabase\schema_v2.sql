
-- Create Bookings Table
create table public.bookings (
  id uuid not null default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  guest_name text not null,
  check_in_date date not null,
  check_out_date date not null,
  status text check (status in ('confirmed', 'pending', 'cancelled')) default 'confirmed',
  total_price numeric,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  
  primary key (id)
);

-- Enable RLS for Bookings
alter table public.bookings enable row level security;

-- Policies for Bookings
-- Access is determined by the OWNER of the property.
-- We join with the properties table to check ownership.

create policy "Users can view bookings for their properties" on bookings
  for select using (
    exists (
      select 1 from properties
      where properties.id = bookings.property_id
      and properties.owner_id = auth.uid()
    )
  );

create policy "Users can insert bookings for their properties" on bookings
  for insert with check (
    exists (
      select 1 from properties
      where properties.id = bookings.property_id
      and properties.owner_id = auth.uid()
    )
  );

create policy "Users can delete bookings for their properties" on bookings
  for delete using (
    exists (
      select 1 from properties
      where properties.id = bookings.property_id
      and properties.owner_id = auth.uid()
    )
  );


-- Create Automations Table
create table public.automations (
  id uuid not null default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  trigger_type text not null, -- e.g. 'booking_created', 'check_in', 'check_out'
  action_type text not null, -- e.g. 'send_email', 'send_sms'
  template_content text, -- The message to send
  is_active boolean default true,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,

  primary key (id)
);

-- Enable RLS for Automations
alter table public.automations enable row level security;

create policy "Users can view automations for their properties" on automations
  for select using (
    exists (
      select 1 from properties
      where properties.id = automations.property_id
      and properties.owner_id = auth.uid()
    )
  );

create policy "Users can manage automations for their properties" on automations
  for all using (
    exists (
      select 1 from properties
      where properties.id = automations.property_id
      and properties.owner_id = auth.uid()
    )
  );
