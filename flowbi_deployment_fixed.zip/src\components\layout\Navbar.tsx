
'use client'

import Link from "next/link";
import { Button } from "@/components/ui/Button";
import { LogOut, LayoutDashboard, User } from "lucide-react";
import { motion } from "framer-motion";

interface NavbarProps {
    user: any;
    logoutAction: () => Promise<void>;
}

export function Navbar({ user, logoutAction }: NavbarProps) {
    return (
        <motion.nav
            initial={{ y: -100 }}
            animate={{ y: 0 }}
            className="fixed top-0 left-0 right-0 z-50 border-b border-border/20 bg-background/70 backdrop-blur-2xl transition-all"
        >
            <div className="container flex h-20 max-w-7xl items-center justify-between px-6">
                <Link href="/" className="flex items-center gap-3 group">
                    <div className="size-10 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                        <div className="size-5 rounded bg-primary rotate-45 group-hover:rotate-180 transition-transform duration-500" />
                    </div>
                    <span className="text-xl font-black tracking-tighter uppercase italic">Flow<span className="text-primary not-italic">bi</span></span>
                </Link>

                <div className="hidden lg:flex items-center gap-8 text-sm font-bold uppercase tracking-widest text-muted-foreground">
                    <Link href="#features" className="hover:text-primary transition-colors">Features</Link>
                    <Link href="#pricing" className="hover:text-primary transition-colors">Pricing</Link>
                    <Link href="#about" className="hover:text-primary transition-colors">Our Goal</Link>
                </div>

                <div className="flex items-center gap-6">
                    {user ? (
                        <div className="flex items-center gap-4">
                            <Link href="/dashboard">
                                <Button size="sm" variant="ghost" className="gap-2 font-bold uppercase tracking-wider text-xs">
                                    <LayoutDashboard size={16} />
                                    Portal
                                </Button>
                            </Link>
                            <form action={logoutAction}>
                                <Button size="sm" variant="outline" className="gap-2 border-2 font-bold uppercase tracking-wider text-xs">
                                    <LogOut size={16} />
                                    Exit
                                </Button>
                            </form>
                        </div>
                    ) : (
                        <div className="flex items-center gap-4">
                            <Link href="/login" className="text-xs font-black uppercase tracking-widest text-muted-foreground hover:text-primary transition-colors">
                                Members
                            </Link>
                            <Link href="/signup">
                                <Button size="lg" className="h-10 px-6 font-black uppercase tracking-widest text-xs">
                                    Join Now
                                </Button>
                            </Link>
                        </div>
                    )}
                </div>
            </div>
        </motion.nav>
    );
}
