
'use client'

import { motion } from "framer-motion";
import {
    MessageSquareText,
    BarChart3,
    CalendarClock,
    ShieldCheck,
    Zap,
    Users,
    Sparkles,
    Bot,
    Languages
} from "lucide-react";

const features = [
    {
        title: "DeepSeek-V3 Messaging",
        description: "Automate 90% of guest inquiries with human-like responses customized to your property context.",
        icon: Bot,
        color: "bg-blue-500/10 text-blue-500",
    },
    {
        title: "Smart Pricing Sync",
        description: "Dynamic pricing algorithms that adjust in real-time to maximize occupancy and revenue.",
        icon: BarChart3,
        color: "bg-orange-500/10 text-orange-500",
    },
    {
        title: "Unified Calendar",
        description: "Sync Airbnb, VRBO, and Booking.com seamlessly. Never worry about double bookings again.",
        icon: CalendarClock,
        color: "bg-purple-500/10 text-purple-500",
    },
    {
        title: "Guest Auto-Vetting",
        description: "Screen guests automatically with advanced ID verification and risk profiling.",
        icon: ShieldCheck,
        color: "bg-green-500/10 text-green-500",
    },
    {
        title: "Maintenance Hub",
        description: "Automatically schedule cleaners and track tasks based on real-time check-out events.",
        icon: Zap,
        color: "bg-yellow-500/10 text-yellow-500",
    },
    {
        title: "Multi-Language OS",
        description: "Communicate with guests world-wide in their native language using real-time translation.",
        icon: Languages,
        color: "bg-rose-500/10 text-rose-500",
    },
];

const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
        opacity: 1,
        transition: {
            staggerChildren: 0.1,
        },
    },
};

const itemVariants: any = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
};

export function Features() {
    return (
        <section id="features" className="relative py-24 sm:py-32 overflow-hidden">
            <div className="container relative z-10 px-4 md:px-6">
                <div className="text-center space-y-6 max-w-3xl mx-auto mb-20">
                    <motion.h2
                        initial={{ opacity: 0, scale: 0.95 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        viewport={{ once: true }}
                        className="text-4xl font-extrabold tracking-tight sm:text-5xl md:text-6xl"
                    >
                        Why Choose <span className="text-primary italic">Flowbi?</span>
                    </motion.h2>
                    <motion.p
                        initial={{ opacity: 0, y: 10 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: 0.2 }}
                        className="text-muted-foreground text-xl md:text-2xl"
                    >
                        We didn't just build a chatbot. We built a property-aware intelligence
                        that understands your house rules, neighborhood, and guests.
                    </motion.p>
                </div>

                <motion.div
                    variants={containerVariants}
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true }}
                    className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3"
                >
                    {features.map((feature, index) => (
                        <motion.div
                            key={index}
                            variants={itemVariants}
                            whileHover={{ y: -10, transition: { duration: 0.2 } }}
                            className="group relative p-8 rounded-3xl border border-border/40 bg-background/40 backdrop-blur-xl shadow-lg hover:shadow-primary/5 transition-all"
                        >
                            <div className={`p-4 w-fit rounded-2xl ${feature.color} mb-6 transition-transform group-hover:scale-110 group-hover:rotate-3`}>
                                <feature.icon className="size-8" />
                            </div>
                            <h3 className="text-2xl font-bold mb-3 group-hover:text-primary transition-colors">
                                {feature.title}
                            </h3>
                            <p className="text-muted-foreground leading-relaxed text-lg">
                                {feature.description}
                            </p>

                            {/* Decorative Corner Glow */}
                            <div className="absolute -bottom-2 -right-2 w-20 h-20 bg-primary/5 rounded-full blur-[40px] opacity-0 group-hover:opacity-100 transition-opacity" />
                        </motion.div>
                    ))}
                </motion.div>
            </div>
        </section>
    );
}
