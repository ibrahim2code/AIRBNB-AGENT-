export async function generateDeepSeekResponse(messages: { role: string; content: string }[]) {
    const apiKey = process.env.OPENROUTER_API_KEY;
    if (!apiKey) {
        throw new Error('OPENROUTER_API_KEY is not defined in environment variables');
    }

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
            "Authorization": `Bearer ${apiKey}`,
            "Content-Type": "application/json",
            "HTTP-Referer": "https://flowbi.online", // Optional site URL
            "X-Title": "Airbnb Automation", // Optional site title
        },
        body: JSON.stringify({
            "model": "nex-agi/deepseek-v3.1-nex-n1:free",
            "messages": messages
        })
    });

    if (!response.ok) {
        const errorData = await response.json();
        console.error('OpenRouter API Error:', errorData);
        throw new Error(errorData?.error?.message || 'Failed to fetch from OpenRouter');
    }

    const data = await response.json();
    return data.choices?.[0]?.message?.content || 'No response from AI';
}
