
import { createClient } from '@/utils/supabase/server'
import { AddBookingForm } from '@/components/dashboard/AddBookingForm'
import { BookingList } from '@/components/dashboard/BookingList'
import { DashboardNav } from '@/components/dashboard/DashboardNav'


export default async function BookingsPage() {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) return <div>Please log in</div>

    // Fetch properties (for the dropdown)
    const { data: properties } = await supabase
        .from('properties')
        .select('id, name')
        .eq('owner_id', user.id)

    // Fetch bookings (and join with property name)
    const { data: bookings } = await supabase
        .from('bookings')
        .select('*, properties(name)')
        // We filter bookings via RLS, but explicit filter is good too ideally:
        // We rely on RLS policy: "Users can view bookings for their properties"
        .order('check_in_date', { ascending: true })

    return (
        <div className="min-h-screen bg-gray-50">
            <DashboardNav />
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900">Bookings</h1>
                        <p className="text-sm text-gray-500 mt-1">Manage your upcoming reservations</p>
                    </div>
                    <AddBookingForm properties={properties || []} />
                </div>

                <BookingList bookings={bookings || []} />
            </div>
        </div>
    )
}
