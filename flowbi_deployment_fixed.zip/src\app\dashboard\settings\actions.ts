
'use server'

import { createClient } from '@/utils/supabase/server'
import { revalidatePath } from 'next/cache'

export async function updatePropertySettings(formData: FormData) {
    const supabase = await createClient()

    const propertyId = formData.get('property_id') as string // We'll need to pass this carefully
    const wifiName = formData.get('wifi_name') as string
    const wifiPassword = formData.get('wifi_password') as string
    const checkIn = formData.get('check_in_instructions') as string
    const rules = formData.get('house_rules') as string
    const parking = formData.get('parking_instructions') as string
    const neighborhood = formData.get('neighborhood_tips') as string
    const checkout = formData.get('checkout_instructions') as string
    const manual = formData.get('house_manual_link') as string
    const ical = formData.get('ical_link') as string

    // We need to ensure the user owns this property before updating
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return { error: 'Not authenticated' }

    const { error } = await supabase.from('properties')
        .update({
            wifi_name: wifiName,
            wifi_password: wifiPassword,
            check_in_instructions: checkIn,
            house_rules: rules,
            parking_instructions: parking,
            neighborhood_tips: neighborhood,
            checkout_instructions: checkout,
            house_manual_link: manual,
            ical_link: ical
        })
        .eq('id', propertyId)
        .eq('owner_id', user.id) // Security check

    if (error) {
        console.error('Error updating property:', error)
        return { error: 'Failed to update property' }
    }

    revalidatePath('/dashboard/settings')
    return { success: true }
}
