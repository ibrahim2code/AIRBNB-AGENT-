
-- Reset setup (be careful, this deletes data in these tables!)
drop trigger if exists on_auth_user_created on auth.users;
drop function if exists public.handle_new_user();
drop table if exists public.properties;
drop table if exists public.profiles;

-- Create a table for public profiles using the auth.users table properties
create table public.profiles (
  id uuid not null references auth.users on delete cascade,
  first_name text,
  last_name text,
  email text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,

  primary key (id)
);

alter table public.profiles enable row level security;

create policy "Users can view their own profile" on profiles
  for select using (auth.uid() = id);

create policy "Users can update their own profile" on profiles
  for update using (auth.uid() = id);

-- Create a table for properties
create table public.properties (
  id uuid not null default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  address text,
  description text,
  price_per_night numeric,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null,

  primary key (id)
);

alter table public.properties enable row level security;

create policy "Users can view their own properties" on properties
  for select using (auth.uid() = owner_id);

create policy "Users can insert their own properties" on properties
  for insert with check (auth.uid() = owner_id);

create policy "Users can update their own properties" on properties
  for update using (auth.uid() = owner_id);

create policy "Users can delete their own properties" on properties
  for delete using (auth.uid() = owner_id);

-- Sets up a trigger to automatically create a profile entry when a new user signs up via Supabase Auth.
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, first_name, last_name)
  values (new.id, new.email, new.raw_user_meta_data->>'first_name', new.raw_user_meta_data->>'last_name');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
