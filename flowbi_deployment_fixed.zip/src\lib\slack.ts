
// Note: Requires @slack/bolt and @slack/web-api
import { WebClient } from '@slack/web-api';

const slackClient = new WebClient(process.env.SLACK_BOT_TOKEN);

export async function sendSlackApprovalRequest({
    messageId,
    guestName,
    platform,
    guestMessage,
    draftReply
}: {
    messageId: string;
    guestName: string;
    platform: string;
    guestMessage: string;
    draftReply: string;
}) {
    const channelId = process.env.SLACK_APPROVALS_CHANNEL_ID!;

    const icon = platform === 'whatsapp' ? '🟢' : '🏠';

    return await slackClient.chat.postMessage({
        channel: channelId,
        text: `New approval request from ${guestName}`,
        blocks: [
            {
                type: "section",
                text: {
                    type: "mrkdwn",
                    text: `*Approval Request* ${icon} *${platform.toUpperCase()}*`
                }
            },
            {
                type: "section",
                text: {
                    type: "mrkdwn",
                    text: `*Guest:* ${guestName}\n*Guest said:* "${guestMessage}"`
                }
            },
            {
                type: "input",
                block_id: "reply_block",
                element: {
                    type: "plain_text_input",
                    action_id: "reply_input",
                    initial_value: draftReply,
                    multiline: true
                },
                label: {
                    type: "plain_text",
                    text: "Review/Edit Draft Reply"
                }
            },
            {
                type: "actions",
                elements: [
                    {
                        type: "button",
                        text: {
                            type: "plain_text",
                            text: "Approve & Send"
                        },
                        style: "primary",
                        value: messageId,
                        action_id: "approve_reply"
                    },
                    {
                        type: "button",
                        text: {
                            type: "plain_text",
                            text: "Reject"
                        },
                        style: "danger",
                        value: messageId,
                        action_id: "reject_reply"
                    }
                ]
            }
        ]
    });
}

export async function logToSlack(message: string) {
    const logChannel = process.env.SLACK_LOGS_CHANNEL_ID;
    if (!logChannel) return;

    try {
        await slackClient.chat.postMessage({
            channel: logChannel,
            text: `[INFO]: ${message}`
        });
    } catch (error) {
        console.error('Slack logging failed:', error);
    }
}
