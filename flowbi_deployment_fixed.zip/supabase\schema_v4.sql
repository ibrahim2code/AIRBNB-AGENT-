
-- Add AI Automation toggle to properties
alter table public.properties add column if not exists ai_automation_enabled boolean default false;

-- Create Messages Table
create table if not exists public.messages (
  id uuid not null default gen_random_uuid(),
  booking_id uuid references public.bookings(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  sender_type text check (sender_type in ('guest', 'host', 'ai')) not null,
  sender_name text,
  content text not null,
  external_thread_id text, -- Airbnb thread ID
  external_message_id text, -- Airbnb message ID
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  
  primary key (id)
);

-- Enable RLS for Messages
alter table public.messages enable row level security;

-- Policies for Messages
create policy "Users can view messages for their properties" on messages
  for select using (
    exists (
      select 1 from properties
      where properties.id = messages.property_id
      and properties.owner_id = auth.uid()
    )
  );

create policy "Users can insert messages for their properties" on messages
  for insert with check (
    exists (
      select 1 from properties
      where properties.id = messages.property_id
      and properties.owner_id = auth.uid()
    )
  );
