
import { createClient } from '@/utils/supabase/server'
import { PropertySettingsForm } from '@/components/dashboard/PropertySettingsForm'
import { DashboardNav } from '@/components/dashboard/DashboardNav'
import { AgentSimulator } from '@/components/dashboard/AgentSimulator'
import AirbnbConnect from '@/components/dashboard/AirbnbConnect'

export default async function SettingsPage() {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) return <div>Please log in</div>

    // Fetch user profile for connection status
    const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single()

    // Fetch properties with their current settings
    const { data: properties } = await supabase
        .from('properties')
        .select('*')
        .eq('owner_id', user.id)

    return (
        <div className="min-h-screen bg-gray-50 pb-20">
            <DashboardNav />
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <div className="mb-8 flex flex-col items-center">
                    <h1 className="text-3xl font-extrabold text-gray-900 tracking-tight">AI Co-Host Integration</h1>
                    <p className="text-gray-500 mt-2 text-center max-w-md">Connect your Airbnb account and teach your agent how to host your guests flawlessly.</p>
                </div>

                {/* Account Connection Section */}
                <div className="max-w-2xl mx-auto mb-12">
                    <AirbnbConnect
                        isConnected={profile?.airbnb_connected || false}
                        connectedAt={profile?.airbnb_connected_at || null}
                    />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
                    <div>
                        <div className="mb-4">
                            <h2 className="text-xl font-bold text-gray-900">Knowledge Base</h2>
                            <p className="text-sm text-gray-500">Update property details the AI should know.</p>
                        </div>
                        <PropertySettingsForm properties={properties || []} />
                    </div>

                    <div className="sticky top-8">
                        <div className="mb-4">
                            <h2 className="text-xl font-bold text-gray-900">Agent Playground</h2>
                            <p className="text-sm text-gray-500">Test the AI's response before going live.</p>
                        </div>
                        <AgentSimulator properties={properties || []} />
                    </div>
                </div>
            </div>
        </div>
    )
}
