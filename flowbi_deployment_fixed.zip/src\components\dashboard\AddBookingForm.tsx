
'use client'

import { useState } from 'react'
import { addBooking } from '@/app/dashboard/bookings/actions'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Plus, X, Calendar } from 'lucide-react'

// Passing properties as props so the user can select which property this booking is for
export function AddBookingForm({ properties }: { properties: any[] }) {
    const [isOpen, setIsOpen] = useState(false)
    const [isSubmitting, setIsSubmitting] = useState(false)

    async function handleSubmit(formData: FormData) {
        setIsSubmitting(true)
        await addBooking(formData)
        setIsSubmitting(false)
        setIsOpen(false)
    }

    if (!isOpen) {
        return (
            <Button onClick={() => setIsOpen(true)} className="flex items-center gap-2">
                <Plus size={16} /> New Booking
            </Button>
        )
    }

    if (properties.length === 0) {
        return (
            <Card className="p-4 bg-yellow-50 border border-yellow-200">
                <div className="flex justify-between items-center">
                    <span className="text-sm text-yellow-800">You need to add a property first.</span>
                    <button onClick={() => setIsOpen(false)}><X size={16} /></button>
                </div>
            </Card>
        )
    }

    return (
        <Card className="p-6 mb-6 bg-white border border-gray-200 shadow-sm">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                    <Calendar size={18} className="text-indigo-600" /> New Reservation
                </h3>
                <button onClick={() => setIsOpen(false)} className="text-gray-500 hover:text-gray-700">
                    <X size={20} />
                </button>
            </div>
            <form action={handleSubmit} className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700">Select Property</label>
                    <select
                        name="property_id"
                        required
                        className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:ring-indigo-500 bg-white"
                    >
                        {properties.map(p => (
                            <option key={p.id} value={p.id}>{p.name}</option>
                        ))}
                    </select>
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700">Guest Name</label>
                    <input
                        name="guest_name"
                        required
                        type="text"
                        className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:ring-indigo-500"
                        placeholder="John Doe"
                    />
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Check In</label>
                        <input
                            name="check_in"
                            required
                            type="date"
                            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:ring-indigo-500"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Check Out</label>
                        <input
                            name="check_out"
                            required
                            type="date"
                            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:ring-indigo-500"
                        />
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700">Total Price ($)</label>
                    <input
                        name="total_price"
                        type="number"
                        min="0"
                        step="0.01"
                        className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:ring-indigo-500"
                        placeholder="0.00"
                    />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                    <Button type="button" variant="secondary" onClick={() => setIsOpen(false)}>
                        Cancel
                    </Button>
                    <Button type="submit" disabled={isSubmitting}>
                        {isSubmitting ? 'Creating...' : 'Create Reservation'}
                    </Button>
                </div>
            </form>
        </Card>
    )
}
