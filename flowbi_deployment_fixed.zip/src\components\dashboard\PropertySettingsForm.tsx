
'use client'

import { useState } from 'react'
import { updatePropertySettings } from '@/app/dashboard/settings/actions'
import { syncCalendar } from '@/app/dashboard/settings/sync-actions'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Wifi, FileText, Info, Zap, Languages } from 'lucide-react'

// This form takes a list of properties, asks user to select one, then lets them edit.
// Ideally, this should be on a per-property page. For MVP, a dropdown selector is fine.
export function PropertySettingsForm({ properties }: { properties: any[] }) {
    const [selectedPropId, setSelectedPropId] = useState(properties[0]?.id || '')
    const [isSubmitting, setIsSubmitting] = useState(false)

    // In a real app we'd fetch the specific property details when selected to pre-fill.
    // For MVP, we'll just rely on the user typing new values or we could pass full objects.
    const selectedProp = properties.find(p => p.id === selectedPropId)

    async function handleSubmit(formData: FormData) {
        setIsSubmitting(true)
        await updatePropertySettings(formData)
        setIsSubmitting(false)
        alert('Settings saved!')
    }

    if (properties.length === 0) {
        return <div>No properties found.</div>
    }

    return (
        <Card className="p-6 bg-white border border-gray-200 shadow-sm max-w-2xl mx-auto">
            <div className="mb-6">
                <h3 className="text-lg font-semibold mb-2">Configure AI Knowledge</h3>
                <p className="text-sm text-gray-500">
                    Select a property and tell the AI about it. It will use this info to answer guest questions.
                </p>
            </div>

            <form action={handleSubmit} className="space-y-6">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Select Property</label>
                    <select
                        name="property_id"
                        value={selectedPropId}
                        onChange={(e) => setSelectedPropId(e.target.value)}
                        className="block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:ring-indigo-500 bg-white"
                    >
                        {properties.map(p => (
                            <option key={p.id} value={p.id}>{p.name}</option>
                        ))}
                    </select>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-orange-50/50 p-4 rounded-xl border border-orange-100">
                        <div className="flex items-center gap-2 mb-3 text-orange-700 font-bold">
                            <Wifi size={18} /> Connectivity
                        </div>
                        <div className="space-y-3">
                            <div>
                                <label className="block text-[10px] font-black text-orange-600/70 uppercase tracking-widest">Network Name</label>
                                <input
                                    name="wifi_name"
                                    type="text"
                                    defaultValue={selectedProp?.wifi_name || ''}
                                    className="mt-1 block w-full rounded-lg border border-orange-200 px-3 py-2 text-sm bg-white focus:ring-2 focus:ring-orange-500/20 transition-all outline-none"
                                    placeholder="e.g. Seaside Guest"
                                />
                            </div>
                            <div>
                                <label className="block text-[10px] font-black text-orange-600/70 uppercase tracking-widest">Password</label>
                                <input
                                    name="wifi_password"
                                    type="text"
                                    defaultValue={selectedProp?.wifi_password || ''}
                                    className="mt-1 block w-full rounded-lg border border-orange-200 px-3 py-2 text-sm bg-white focus:ring-2 focus:ring-orange-500/20 transition-all outline-none"
                                    placeholder="e.g. secret123"
                                />
                            </div>
                        </div>
                    </div>

                    <div className="bg-blue-50/50 p-4 rounded-xl border border-blue-100">
                        <div className="flex items-center gap-2 mb-3 text-blue-700 font-bold">
                            <Info size={18} /> Moving In/Out
                        </div>
                        <div className="space-y-3">
                            <div>
                                <label className="block text-[10px] font-black text-blue-600/70 uppercase tracking-widest">Check-in Instructions</label>
                                <textarea
                                    name="check_in_instructions"
                                    rows={2}
                                    defaultValue={selectedProp?.check_in_instructions || ''}
                                    className="mt-1 block w-full rounded-lg border border-blue-200 px-3 py-2 text-sm bg-white focus:ring-2 focus:ring-blue-500/20 transition-all outline-none"
                                    placeholder="e.g. Code is 1234..."
                                />
                            </div>
                            <div>
                                <label className="block text-[10px] font-black text-blue-600/70 uppercase tracking-widest">Checkout Rules</label>
                                <textarea
                                    name="checkout_instructions"
                                    rows={2}
                                    defaultValue={selectedProp?.checkout_instructions || ''}
                                    className="mt-1 block w-full rounded-lg border border-blue-200 px-3 py-2 text-sm bg-white focus:ring-2 focus:ring-blue-500/20 transition-all outline-none"
                                    placeholder="e.g. Strip beds, start dishwasher..."
                                />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-purple-50/50 p-4 rounded-xl border border-purple-100">
                        <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2 text-purple-700 font-bold">
                                <Zap size={18} /> Logistics & Sync
                            </div>
                            {selectedProp?.last_sync_at && (
                                <span className="text-[10px] text-purple-600 font-medium">
                                    Last Sync: {new Date(selectedProp.last_sync_at).toLocaleTimeString()}
                                </span>
                            )}
                        </div>
                        <div className="space-y-3">
                            <div>
                                <label className="block text-[10px] font-black text-purple-600/70 uppercase tracking-widest">Airbnb iCal Link</label>
                                <div className="flex gap-2">
                                    <input
                                        name="ical_link"
                                        type="text"
                                        defaultValue={selectedProp?.ical_link || ''}
                                        className="mt-1 block w-full rounded-lg border border-purple-200 px-3 py-2 text-sm bg-white focus:ring-2 focus:ring-purple-500/20 transition-all outline-none"
                                        placeholder="https://www.airbnb.com/calendar/ical/..."
                                    />
                                    <Button
                                        type="button"
                                        variant="outline"
                                        size="sm"
                                        className="mt-1 h-9 border-purple-200 text-purple-700 hover:bg-purple-100"
                                        onClick={async () => {
                                            const res = await syncCalendar(selectedPropId);
                                            if (res.success) alert(`Synced ${res.count} events!`);
                                            else alert(res.error);
                                        }}
                                    >
                                        Sync Now
                                    </Button>
                                </div>
                            </div>
                            <div>
                                <label className="block text-[10px] font-black text-purple-600/70 uppercase tracking-widest">Parking Info</label>
                                <textarea
                                    name="parking_instructions"
                                    rows={1}
                                    defaultValue={selectedProp?.parking_instructions || ''}
                                    className="mt-1 block w-full rounded-lg border border-purple-200 px-3 py-2 text-sm bg-white focus:ring-2 focus:ring-purple-500/20 transition-all outline-none"
                                    placeholder="e.g. Park in slot #12..."
                                />
                            </div>
                        </div>
                    </div>

                    <div className="bg-green-50/50 p-4 rounded-xl border border-green-100">
                        <div className="flex items-center gap-2 mb-3 text-green-700 font-bold">
                            <FileText size={18} /> Documents & Rules
                        </div>
                        <div className="space-y-3">
                            <div>
                                <label className="block text-[10px] font-black text-green-600/70 uppercase tracking-widest">House Manual Link (PDF/Web)</label>
                                <input
                                    name="house_manual_link"
                                    type="text"
                                    defaultValue={selectedProp?.house_manual_link || ''}
                                    className="mt-1 block w-full rounded-lg border border-green-200 px-3 py-2 text-sm bg-white focus:ring-2 focus:ring-green-500/20 transition-all outline-none"
                                    placeholder="https://..."
                                />
                            </div>
                            <div>
                                <label className="block text-[10px] font-black text-green-600/70 uppercase tracking-widest">House Rules Summary</label>
                                <textarea
                                    name="house_rules"
                                    rows={2}
                                    defaultValue={selectedProp?.house_rules || ''}
                                    className="mt-1 block w-full rounded-lg border border-green-200 px-3 py-2 text-sm bg-white focus:ring-2 focus:ring-green-500/20 transition-all outline-none"
                                    placeholder="e.g. No smoking..."
                                />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="flex justify-end pt-4 border-t border-gray-100">
                    <Button type="submit" disabled={isSubmitting}>
                        {isSubmitting ? 'Saving...' : 'Save Knowledge Base'}
                    </Button>
                </div>
            </form>
        </Card>
    )
}
