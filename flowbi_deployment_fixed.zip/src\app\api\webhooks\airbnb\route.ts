import { createClient } from '@/utils/supabase/server'
import { generateDeepSeekResponse } from '@/lib/openrouter'
import { sendAirbnbMessage } from '@/lib/airbnb'

export async function POST(request: Request) {
    const supabase = await createClient()
    const body = await request.json()

    // Official Airbnb Webhook Structure (Standardized for messaging)
    const {
        property_id,
        listing_id, // Airbnb's ID
        thread_id, // Airbnb thread ID
        content, // Message content
        sender_id,
        sender_name
    } = body

    // Use property_id or map from listing_id
    const targetPropertyId = property_id || await mapListingId(listing_id, supabase)

    if (!targetPropertyId || (!content && !thread_id)) {
        return new Response('Missing required fields or unrecognized property', { status: 400 })
    }

    // 1. Fetch Property Context and Check if AI is enabled
    const { data: property, error: propError } = await supabase
        .from('properties')
        .select('*')
        .eq('id', targetPropertyId)
        .single()

    if (propError || !property) {
        return new Response('Property not found', { status: 404 })
    }

    // 2. Save Message to DB (Conversation History)
    const { error: msgError } = await supabase.from('messages').insert({
        property_id: targetPropertyId,
        sender_type: 'guest',
        sender_name: sender_name || 'Guest',
        content: content,
        external_thread_id: thread_id,
        source: 'airbnb'
    })

    if (msgError) console.error('Error saving message:', msgError)

    // 3. Automated AI Response Loop
    if (property.ai_automation_enabled) {
        console.log(`DeepSeek processing message for: ${property.name}`)

        const systemPrompt = `
            You are a polite Airbnb Co-Host for "${property.name}".
            Wifi: ${property.wifi_name} / ${property.wifi_password}
            Check-in: ${property.check_in_instructions}
            Rules: ${property.house_rules}
            Answer concisely based on this info.
        `

        try {
            const aiReply = await generateDeepSeekResponse([
                { role: "system", content: systemPrompt },
                { role: "user", content: content }
            ])

            // 4. Send Message BACK to Airbnb Official API
            await sendAirbnbMessage(thread_id, aiReply)

            // 5. Save AI Response to local Inbox
            await supabase.from('messages').insert({
                property_id: targetPropertyId,
                sender_type: 'ai',
                sender_name: 'AI Co-Host',
                content: aiReply,
                external_thread_id: thread_id,
                source: 'airbnb'
            })

            return Response.json({ success: true, replied: aiReply })

        } catch (error) {
            console.error('AI Processing/Send Error:', error)
            return Response.json({ success: false, error: 'Failed to process AI response' })
        }
    }

    return Response.json({ success: true, info: 'Message logged' })
}

async function mapListingId(listingId: string, supabase: any) {
    if (!listingId) return null
    // Here we would ideally have a mapping table if internal IDs don't match Airbnb listing IDs
    const { data } = await supabase.from('properties').select('id').eq('external_id', listingId).single()
    return data?.id || null
}
