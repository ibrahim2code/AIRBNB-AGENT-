
import dotenv from 'dotenv';
import path from 'path';

// Load .env.local
dotenv.config({ path: path.resolve(process.cwd(), '.env.local') });

async function verifyAirbnbAPI() {
    console.log('--- Testing Airbnb API Connectivity ---');
    const apiKey = process.env.AIRBNB_API_KEY;
    const apiSecret = process.env.AIRBNB_API_SECRET;

    if (!apiKey || !apiSecret) {
        console.error('❌ Error: Missing AIRBNB_API_KEY or AIRBNB_API_SECRET in .env.local');
        return;
    }

    console.log(`Using API Key: ${apiKey.substring(0, 5)}...`);

    // We'll try to call a standard v2 endpoint. 
    // Even if it returns 401/403 due to OAuth requirements, 
    // we want to see if the host resolves and if we get a structured response from Airbnb.
    try {
        const response = await fetch('https://api.airbnb.com/v2/listings/12345', {
            method: 'GET',
            headers: {
                'X-Airbnb-API-Key': apiKey,
                'Content-Type': 'application/json'
            }
        });

        const status = response.status;
        console.log(`Response Status: ${status}`);

        if (status === 200) {
            console.log('✅ Success: API Key accepted, listing found.');
        } else if (status === 403 || status === 401) {
            console.log('⚠️ Authentication Error: The key is recognized but might lack "Search/Listing" permissions or requires a full OAuth Bearer token.');
        } else if (status === 404) {
            console.log('✅ Connectivity: Airbnb server replied with 404 (Not Found). This confirms the API Key works for communication, but the test ID doesn\'t exist.');
        } else {
            const data = await response.json().catch(() => ({}));
            console.log('Response Detail:', data);
        }

    } catch (error) {
        console.error('❌ Network Error: Could not reach Airbnb servers.', error);
    }
}

verifyAirbnbAPI();
