
/**
 * Simple robust iCal parser for Airbnb/VRBO calendars.
 * Airbnb iCal format:
 * BEGIN:VCALENDAR
 * ...
 * BEGIN:VEVENT
 * DTEND;VALUE=DATE:20241228
 * DTSTART;VALUE=DATE:20241226
 * SUMMARY:Reserved
 * UID:12345@airbnb.com
 * END:VEVENT
 * ...
 * END:VCALENDAR
 */

export interface ICalEvent {
    start: Date;
    end: Date;
    summary: string;
    uid: string;
}

export function parseICal(data: string): ICalEvent[] {
    const events: ICalEvent[] = [];
    const lines = data.split(/\r?\n/);
    let currentEvent: Partial<ICalEvent> | null = null;

    for (const line of lines) {
        if (line.startsWith('BEGIN:VEVENT')) {
            currentEvent = {};
        } else if (line.startsWith('END:VEVENT')) {
            if (currentEvent && currentEvent.start && currentEvent.end) {
                events.push(currentEvent as ICalEvent);
            }
            currentEvent = null;
        } else if (currentEvent) {
            if (line.startsWith('DTSTART')) {
                const dateStr = line.split(':')[1];
                currentEvent.start = parseICalDate(dateStr);
            } else if (line.startsWith('DTEND')) {
                const dateStr = line.split(':')[1];
                currentEvent.end = parseICalDate(dateStr);
            } else if (line.startsWith('SUMMARY')) {
                currentEvent.summary = line.split(':')[1];
            } else if (line.startsWith('UID')) {
                currentEvent.uid = line.split(':')[1];
            }
        }
    }

    return events;
}

function parseICalDate(dateStr: string): Date {
    // Format: YYYYMMDD or YYYYMMDDTHHMMSSZ
    const y = parseInt(dateStr.substring(0, 4));
    const m = parseInt(dateStr.substring(4, 6)) - 1;
    const d = parseInt(dateStr.substring(6, 8));

    if (dateStr.includes('T')) {
        const h = parseInt(dateStr.substring(9, 11));
        const min = parseInt(dateStr.substring(11, 13));
        const s = parseInt(dateStr.substring(13, 15));
        return new Date(Date.UTC(y, m, d, h, min, s));
    }

    return new Date(Date.UTC(y, m, d));
}
